/**
 * VAD behaviour, driven by synthetic 16 kHz audio. These tests are what stop a
 * "small" threshold change from silently swallowing the first word of every
 * sentence.
 *
 * Run with: npm test
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { VAD } from '../src/common/vad.js';

const RATE = 16000;
const FRAME = 1024;
const FRAME_MS = (FRAME / RATE) * 1000; // 64 ms

/** Build a frame of speech-like tone or of room tone. */
function frame(voiced) {
  const f = new Float32Array(FRAME);
  for (let i = 0; i < FRAME; i++) {
    f[i] = voiced ? 0.2 * Math.sin(i / 6) : (Math.random() - 0.5) * 0.002;
  }
  return f;
}

/** Run a timeline of [voiced, durationMs] segments through a VAD. */
function run(vad, timeline) {
  const events = [];
  let elapsed = 0;
  for (const [voiced, ms] of timeline) {
    for (let t = 0; t < ms; t += FRAME_MS) {
      const r = vad.process(frame(voiced));
      if (r.started) events.push({ type: 'open', at: Math.round(elapsed) });
      if (r.ended) events.push({ type: 'close', at: Math.round(elapsed) });
      elapsed += FRAME_MS;
    }
  }
  return events;
}

test('opens shortly after speech begins and closes after the silence window', () => {
  const vad = new VAD({ sampleRate: RATE, threshold: 0.012, silenceMs: 700 });
  const events = run(vad, [[false, 300], [true, 600], [false, 900]]);

  assert.equal(events.length, 2, `expected one open and one close, got ${JSON.stringify(events)}`);

  const [open, close] = events;
  assert.equal(open.type, 'open');
  // Needs ~160 ms of speech to commit, so somewhere in 300–560 ms.
  assert.ok(open.at >= 300 && open.at <= 560, `opened at ${open.at}ms`);

  assert.equal(close.type, 'close');
  // Speech ends at 900 ms, plus a 700 ms silence window, plus frame quantisation.
  assert.ok(close.at >= 1550 && close.at <= 1750, `closed at ${close.at}ms`);
});

test('a short blip never opens an utterance', () => {
  const vad = new VAD({ sampleRate: RATE, threshold: 0.012, silenceMs: 700 });
  const events = run(vad, [[false, 200], [true, 80], [false, 900]]);
  assert.deepEqual(events, [], 'a 80 ms click should not be treated as speech');
});

test('a brief pause mid-sentence does not split the utterance', () => {
  const vad = new VAD({ sampleRate: RATE, threshold: 0.012, silenceMs: 700 });
  const events = run(vad, [[false, 200], [true, 500], [false, 300], [true, 500], [false, 900]]);
  assert.equal(events.filter((e) => e.type === 'open').length, 1);
  assert.equal(events.filter((e) => e.type === 'close').length, 1);
});

test('a shorter silence window closes sooner', () => {
  const fast = new VAD({ sampleRate: RATE, threshold: 0.012, silenceMs: 350 });
  const events = run(fast, [[false, 200], [true, 500], [false, 800]]);
  const close = events.find((e) => e.type === 'close');
  assert.ok(close, 'expected the utterance to close');
  assert.ok(close.at < 1200, `closed at ${close.at}ms, expected under 1200ms`);
});

test('the meter level tracks loudness and decays', () => {
  const vad = new VAD({ sampleRate: RATE });
  for (let i = 0; i < 10; i++) vad.process(frame(true));
  const loud = vad.level;
  assert.ok(loud > 0.3, `expected a lit meter while speaking, got ${loud.toFixed(3)}`);

  for (let i = 0; i < 40; i++) vad.process(frame(false));
  assert.ok(vad.level < loud * 0.5, 'expected the meter to fall back during silence');
});

test('reset clears state between utterances', () => {
  const vad = new VAD({ sampleRate: RATE });
  run(vad, [[true, 400]]);
  assert.equal(vad.speaking, true);
  vad.reset();
  assert.equal(vad.speaking, false);
  assert.equal(vad.level, 0);
});

test('raising the threshold rejects quiet input', () => {
  const strict = new VAD({ sampleRate: RATE, threshold: 0.5, silenceMs: 700 });
  const events = run(strict, [[false, 200], [true, 800], [false, 900]]);
  assert.deepEqual(events, [], 'a 0.5 RMS gate should reject a 0.2 amplitude tone');
});
