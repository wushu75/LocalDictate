/**
 * Post-processing is the only part of LocalDictate that is pure logic, so it
 * is the only part that can be tested without a browser. It is also the part
 * most likely to be broken by a well-meaning regex tweak.
 *
 * Run with: npm test
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { postProcess, isNoiseOnly } from '../src/common/postprocess.js';

const settings = {
  removeFillers: true,
  autoCapitalize: true,
  smartPunctuation: true,
  trailingPunctuation: false,
  customReplacements: [{ from: 'local dictate', to: 'LocalDictate' }]
};

test('removes fillers without leaving orphaned punctuation', () => {
  assert.equal(
    postProcess('so i was thinking , uh , we should ship it', settings),
    'So I was thinking, we should ship it'
  );
});

test('strips a leading filler and capitalises what follows', () => {
  assert.equal(postProcess(' um so we start here', settings), 'So we start here');
});

test('does not eat real words that begin with a filler', () => {
  assert.equal(postProcess('the umbrella is uh blue', settings), 'The umbrella is blue');
  assert.match(postProcess('erm, ahead of schedule', settings), /Ahead of schedule/);
});

test('honours spoken punctuation commands', () => {
  assert.equal(postProcess('hello world question mark', settings), 'Hello world?');
  assert.equal(
    postProcess('the meeting is at 3 comma right after lunch period', settings),
    'The meeting is at 3, right after lunch.'
  );
});

test('turns "new paragraph" into a real break', () => {
  assert.equal(postProcess('ship it new paragraph then tell people', settings), 'Ship it\n\nThen tell people');
});

test('capitalises the pronoun I and its contractions', () => {
  assert.equal(postProcess("i think i'll do it", settings), "I think I'll do it");
});

test('applies user replacements case-insensitively', () => {
  assert.equal(postProcess('tell people about Local Dictate', settings), 'Tell people about LocalDictate');
});

test('a malformed user rule cannot break dictation', () => {
  const broken = { ...settings, customReplacements: [{ from: '([', to: 'x', regex: true }] };
  assert.equal(postProcess('this still works', broken), 'This still works');
});

test('drops bracketed audio events entirely', () => {
  assert.equal(postProcess('[BLANK_AUDIO]', settings), '');
  assert.equal(postProcess('♪♪♪', settings), '');
});

test('recognises Whisper hallucinations as noise', () => {
  assert.ok(isNoiseOnly(''));
  assert.ok(isNoiseOnly('[BLANK_AUDIO]'));
  assert.ok(isNoiseOnly('Thanks for watching!'));
  assert.ok(isNoiseOnly('...'));
  assert.ok(!isNoiseOnly('Thanks for watching the presentation, everyone.'));
});

test('trailing punctuation is opt-in', () => {
  assert.equal(postProcess('ending without any', settings), 'Ending without any');
  assert.equal(
    postProcess('now there is', { ...settings, trailingPunctuation: true }),
    'Now there is.'
  );
});

test('spoken commands win over their literal words — a documented tradeoff', () => {
  // Saying "full stop" inserts a period, so the literal phrase cannot be
  // dictated. Every dictation system makes this trade; this test exists so the
  // behaviour is a decision rather than a surprise. Users who need the literal
  // words can add a replacement rule in Settings.
  assert.equal(postProcess('no full stop here', settings), 'No. Here');
  assert.equal(postProcess('use a comma there', settings), 'Use a, there');
});

test('each clean-up switch can be turned off independently', () => {
  const off = { removeFillers: false, autoCapitalize: false, smartPunctuation: false };
  assert.equal(postProcess('um hello there', off), 'um hello there');
});

test('never returns undefined or null', () => {
  for (const input of ['', null, undefined, '   ']) {
    assert.equal(typeof postProcess(input, settings), 'string');
  }
});
