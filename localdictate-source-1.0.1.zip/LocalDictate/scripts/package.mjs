#!/usr/bin/env node
/**
 * Builds dist/localdictate-<version>.zip containing exactly what the Chrome Web
 * Store needs — no node_modules, no scripts, no store copy, no dotfiles.
 *
 * Run with: npm run package
 */

import { mkdir, rm, cp, readFile, readdir, stat } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const dist = path.join(root, 'dist');

const INCLUDE = ['manifest.json', 'LICENSE', 'src', 'icons', 'lib'];
const EXCLUDE = new Set(['icon512.png', 'README.md', '.DS_Store']);

async function dirSize(dir) {
  let total = 0;
  for (const entry of await readdir(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    total += entry.isDirectory() ? await dirSize(full) : (await stat(full)).size;
  }
  return total;
}

async function main() {
  const manifest = JSON.parse(await readFile(path.join(root, 'manifest.json'), 'utf8'));
  const stage = path.join(dist, 'localdictate');

  await rm(dist, { recursive: true, force: true });
  await mkdir(stage, { recursive: true });

  for (const item of INCLUDE) {
    await cp(path.join(root, item), path.join(stage, item), {
      recursive: true,
      filter: (src) => !EXCLUDE.has(path.basename(src))
    });
  }

  const zipName = `localdictate-${manifest.version}.zip`;
  const result = spawnSync('zip', ['-qr', path.join('..', zipName), '.'], {
    cwd: stage,
    stdio: 'inherit'
  });
  if (result.status !== 0) {
    console.error('zip failed — install `zip` or archive dist/localdictate yourself.');
    process.exit(1);
  }

  const size = (await stat(path.join(dist, zipName))).size;
  console.log(`\n  dist/${zipName}  (${(size / 1e6).toFixed(1)} MB)`);
  console.log(`  unpacked: ${((await dirSize(stage)) / 1e6).toFixed(1)} MB\n`);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
