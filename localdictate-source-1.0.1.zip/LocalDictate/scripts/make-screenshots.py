#!/usr/bin/env python3
"""
Render Chrome Web Store assets from the design system.

IMPORTANT — READ BEFORE SUBMITTING
These are faithful renders of the real UI, drawn from the same tokens as
src/common/theme.css. They are intended as (a) placeholders so the listing can
be assembled before the extension is loadable, and (b) an exact spec for the
real captures. Chrome Web Store policy expects screenshots to depict actual
functionality, so replace these with genuine captures of the running extension
before you publish. See store/screenshots/README.md for the capture procedure.

Usage:  python3 scripts/make-screenshots.py
Output: store/screenshots/*.png  (1280x800 RGB, no alpha)
        store/promo-440x280.png
"""

from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

OUT = Path(__file__).resolve().parent.parent / "store" / "screenshots"
OUT.mkdir(parents=True, exist_ok=True)
PROMO = OUT.parent / "promo-440x280.png"

W, H = 1280, 800
SS = 2  # supersample, then downscale for clean edges

# --- tokens, mirrored from src/common/theme.css ---------------------------
VOID = (16, 19, 24)
PANEL = (23, 27, 34)
PANEL2 = (30, 35, 44)
PANEL3 = (37, 43, 54)
LINE = (42, 48, 59)
TEXT = (231, 234, 240)
DIM = (138, 148, 166)
FAINT = (93, 102, 118)
SIGNAL = (242, 160, 61)
SIGNAL_DEAD = (44, 42, 38)
VIOLET = (139, 128, 249)
OK = (92, 201, 167)

L_VOID = (232, 235, 240)
L_PANEL = (255, 255, 255)
L_PANEL2 = (242, 244, 248)
L_LINE = (214, 220, 230)
L_TEXT = (22, 26, 33)
L_DIM = (91, 100, 117)
L_SIGNAL = (193, 115, 26)

FONTS = {
    "sans": "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    "sans_bold": "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    "mono": "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf",
}
_cache = {}


def font(kind: str, size: int):
    key = (kind, size)
    if key not in _cache:
        _cache[key] = ImageFont.truetype(FONTS[kind], size * SS)
    return _cache[key]


def canvas(bg):
    img = Image.new("RGB", (W * SS, H * SS), bg)
    return img, ImageDraw.Draw(img)


def s(v):
    """Scale a design-space value into supersampled space."""
    return int(v * SS)


def panel(d, box, fill=PANEL, outline=LINE, radius=12, width=1):
    x0, y0, x1, y1 = [s(v) for v in box]
    d.rounded_rectangle([x0, y0, x1, y1], radius=s(radius), fill=fill,
                        outline=outline, width=max(1, s(width)))


def text(d, xy, string, kind="sans", size=13, fill=TEXT, tracking=0, anchor=None):
    x, y = s(xy[0]), s(xy[1])
    f = font(kind, size)
    if tracking:
        for ch in string:
            d.text((x, y), ch, font=f, fill=fill, anchor=anchor)
            x += d.textlength(ch, font=f) + s(tracking)
        return
    d.text((x, y), string, font=f, fill=fill, anchor=anchor)


def label(d, xy, string, fill=FAINT, size=9):
    text(d, xy, string.upper(), kind="mono", size=size, fill=fill, tracking=1.4)


def lamp(d, xy, colour, halo=None):
    x, y, r = s(xy[0]), s(xy[1]), s(4)
    if halo:
        d.ellipse([x - r - s(3), y - r - s(3), x + r + s(3), y + r + s(3)], fill=halo)
    d.ellipse([x - r, y - r, x + r, y + r], fill=colour)


def meter(d, box, level, segments=24, dead=SIGNAL_DEAD, live=SIGNAL, voiced=True):
    """The signature element: discrete segments, hardware-style."""
    x0, y0, x1, y1 = box
    gap = 3
    seg_w = (x1 - x0 - gap * (segments - 1)) / segments
    lit = round(min(1.0, level) * segments)
    for i in range(segments):
        left = x0 + i * (seg_w + gap)
        on = i < lit
        colour = live if (on and voiced) else (dead if not on else (74, 71, 64))
        d.rounded_rectangle(
            [s(left), s(y0), s(left + seg_w), s(y1)], radius=s(1.5), fill=colour
        )


def chip(d, xy, string, colour=OK, border=None):
    x, y = xy
    f = font("mono", 9)
    w = d.textlength(string.upper(), font=f) + s(20)
    d.rounded_rectangle([s(x), s(y), s(x) + w, s(y + 20)], radius=s(10),
                        outline=border or colour, width=max(1, s(1)))
    text(d, (x + 10, y + 5), string.upper(), kind="mono", size=9, fill=colour, tracking=1.2)
    return w / SS


def button(d, box, string, primary=False, light=False):
    x0, y0, x1, y1 = box
    fill = SIGNAL if primary else (L_PANEL2 if light else PANEL2)
    outline = SIGNAL if primary else (L_LINE if light else LINE)
    panel(d, box, fill=fill, outline=outline, radius=7)
    colour = (22, 18, 10) if primary else (L_TEXT if light else TEXT)
    kind = "sans_bold" if primary else "sans"
    text(d, ((x0 + x1) / 2, (y0 + y1) / 2), string, kind=kind, size=13,
         fill=colour, anchor="mm")


def caption(d, string, sub=None, light=False):
    """Every screenshot carries one claim in the top band."""
    text(d, (64, 54), string, kind="sans_bold", size=30,
         fill=L_TEXT if light else TEXT)
    if sub:
        text(d, (64, 98), sub, kind="sans", size=15, fill=L_DIM if light else DIM)


def wordmark(d, xy, light=False):
    x, y = xy
    c = L_SIGNAL if light else SIGNAL
    # simplified mic glyph
    d.rounded_rectangle([s(x), s(y), s(x + 9), s(y + 15)], radius=s(4.5), fill=c)
    d.arc([s(x - 5), s(y + 5), s(x + 14), s(y + 22)], start=15, end=165, fill=c, width=s(2))
    d.line([s(x + 4.5), s(y + 20), s(x + 4.5), s(y + 24)], fill=c, width=s(2))
    text(d, (x + 22, y + 5), "LOCALDICTATE", kind="mono", size=10,
         fill=L_TEXT if light else TEXT, tracking=1.8)


def finish(img, name):
    out = img.resize((W, H), Image.LANCZOS).convert("RGB")
    path = OUT / name
    out.save(path, "PNG")
    print(f"  {path.relative_to(OUT.parent.parent)}  {out.size[0]}x{out.size[1]} RGB")
    return out


# ---------------------------------------------------------------------------
# 1. The popup, mid-utterance
# ---------------------------------------------------------------------------
def popup_panel(d, ox, oy, light=False, listening=True, transcript=None, level=0.62):
    """Draw the real popup at ~1.6x. ox/oy is the top-left in design space."""
    w, h = 356, 452
    bg = L_PANEL if light else PANEL
    ln = L_LINE if light else LINE
    tx = L_TEXT if light else TEXT
    dm = L_DIM if light else DIM
    sg = L_SIGNAL if light else SIGNAL

    panel(d, (ox, oy, ox + w, oy + h), fill=bg, outline=ln, radius=14)

    wordmark(d, (ox + 16, oy + 16), light)
    text(d, (ox + w - 46, oy + 20), "\u25d0   \u2699", kind="sans", size=13, fill=dm)

    # transport
    ty = oy + 52
    panel(d, (ox + 14, ty, ox + w - 14, ty + 104),
          fill=L_PANEL2 if light else PANEL, outline=ln, radius=10)
    lamp(d, (ox + 30, ty + 20), sg if listening else OK,
         halo=(58, 44, 26) if (listening and not light) else None)
    text(d, (ox + 44, ty + 13), "Listening" if listening else "Ready",
         kind="sans_bold", size=13, fill=tx)
    chip(d, (ox + w - 96, ty + 10), "WebGPU", colour=OK)
    meter(d, (ox + 28, ty + 40, ox + w - 28, ty + 70), level,
          dead=(221, 216, 207) if light else SIGNAL_DEAD, live=sg)
    label(d, (ox + 28, ty + 80), "Ctrl+Shift+D", fill=FAINT if not light else L_DIM)
    label(d, (ox + w - 132, ty + 80), "3.4s in 610ms", fill=FAINT if not light else L_DIM)

    # primary button
    by = ty + 118
    button(d, (ox + 14, by, ox + w - 14, by + 44),
           "Stop dictating" if listening else "Start dictating",
           primary=not listening, light=light)
    if listening:
        panel(d, (ox + 14, by, ox + w - 14, by + 44), fill=bg, outline=sg, radius=7)
        text(d, (ox + w / 2, by + 22), "Stop dictating", kind="sans_bold",
             size=13, fill=sg, anchor="mm")

    # transcript
    tr = by + 58
    panel(d, (ox + 14, tr, ox + w - 14, tr + 118),
          fill=L_PANEL2 if light else PANEL, outline=ln, radius=10)
    label(d, (ox + 28, tr + 14), "Transcript", fill=FAINT if not light else L_DIM)
    for i, word in enumerate(["Copy", "Export", "Clear"]):
        bx = ox + w - 34 - (3 - i) * 54
        panel(d, (bx, tr + 9, bx + 48, tr + 28),
              fill=L_PANEL if light else PANEL2, outline=ln, radius=5)
        text(d, (bx + 24, tr + 19), word, size=10, fill=dm, anchor="mm")
    lines = transcript or [
        "The quarterly numbers came in ahead of",
        "plan, so let's move the review to Thursday",
        "and give the team a proper heads-up.",
    ]
    for i, line in enumerate(lines):
        text(d, (ox + 28, tr + 40 + i * 22), line, size=12, fill=tx)

    # model row
    mo = tr + 132
    panel(d, (ox + 14, mo, ox + w - 14, mo + 44),
          fill=L_PANEL2 if light else PANEL, outline=ln, radius=10)
    label(d, (ox + 28, mo + 17), "Model", fill=FAINT if not light else L_DIM)
    panel(d, (ox + 76, mo + 10, ox + w - 90, mo + 34),
          fill=L_PANEL if light else PANEL2, outline=ln, radius=6)
    text(d, (ox + 86, mo + 16), "Base \u00b7 recommended", size=11, fill=tx)
    text(d, (ox + w - 74, mo + 16), "Loaded", size=11, fill=OK)

    # privacy line
    lamp(d, (ox + 20, oy + h - 22), OK)
    text(d, (ox + 32, oy + h - 29), "Audio is processed on this device. Nothing is uploaded, ever.",
         size=11, fill=dm)
    return w, h


def shot_popup():
    img, d = canvas(VOID)
    d.rectangle([0, 0, W * SS, s(150)], fill=(19, 22, 28))
    caption(d, "Press the hotkey. Speak. It types.",
            "Whisper runs on your machine \u2014 the audio never leaves it.")
    popup_panel(d, 462, 196, listening=True, level=0.62)
    label(d, (64, H - 52), "1 / 5  \u00b7  the popup while dictating")
    return finish(img, "1-popup.png")


# ---------------------------------------------------------------------------
# 2. Dictating into a page
# ---------------------------------------------------------------------------
def shot_in_page():
    img, d = canvas(VOID)
    d.rectangle([0, 0, W * SS, s(150)], fill=(19, 22, 28))
    caption(d, "Works in any text field, on any site.",
            "Gmail, Notion, Slack, GitHub, or a form nobody has updated since 2011.")

    # a mock compose window
    panel(d, (150, 196, 1130, 636), fill=(24, 28, 35), radius=12)
    d.rectangle([s(150), s(196), s(1130), s(240)], fill=PANEL2)
    panel(d, (150, 196, 1130, 240), fill=PANEL2, radius=12)
    d.rectangle([s(150), s(226), s(1130), s(241)], fill=PANEL2)
    for i, c in enumerate([(226, 95, 87), (231, 179, 74), (92, 201, 167)]):
        d.ellipse([s(172 + i * 20), s(212), s(182 + i * 20), s(222)], fill=c)
    text(d, (640, 218), "New message", size=12, fill=DIM, anchor="mm")

    d.line([s(150), s(241), s(1130), s(241)], fill=LINE, width=s(1))
    for i, (field, value) in enumerate([("To", "team@example.com"), ("Subject", "Thursday review")]):
        y = 262 + i * 38
        label(d, (182, y + 4), field)
        text(d, (268, y), value, size=13, fill=TEXT)
        d.line([s(182), s(y + 26), s(1098), s(y + 26)], fill=(34, 39, 48), width=s(1))

    body = [
        "Hi all,",
        "",
        "The quarterly numbers came in ahead of plan, so let's move the review to",
        "Thursday and give the team a proper heads-up. I'll circulate the deck",
        "tomorrow morning",
    ]
    for i, line in enumerate(body):
        text(d, (182, 350 + i * 26), line, size=14, fill=TEXT if i else DIM)
    # caret
    cx = 182 + 152
    d.rectangle([s(cx), s(350 + 4 * 26 - 2), s(cx + 2), s(350 + 4 * 26 + 18)], fill=SIGNAL)

    # the HUD, exactly as content.css draws it
    hx0, hx1, hy = 396, 884, 560
    panel(d, (hx0, hy, hx1, hy + 42), fill=(18, 21, 27), outline=LINE, radius=21)
    lamp(d, (hx0 + 22, hy + 21), SIGNAL, halo=(58, 44, 26))
    label(d, (hx0 + 36, hy + 15), "On device")
    meter(d, (hx0 + 116, hy + 13, hx0 + 192, hy + 29), 0.58, segments=14)
    text(d, (hx0 + 206, hy + 13), "and give the team a proper heads-up\u2026",
         size=12, fill=TEXT)
    panel(d, (hx1 - 76, hy + 9, hx1 - 12, hy + 33), fill=PANEL2, outline=LINE, radius=12)
    text(d, (hx1 - 44, hy + 21), "Stop", size=11, fill=TEXT, anchor="mm")

    label(d, (64, H - 52), "2 / 5  \u00b7  text lands where your caret is")
    return finish(img, "2-in-page.png")


# ---------------------------------------------------------------------------
# 3. Privacy panel
# ---------------------------------------------------------------------------
def shot_privacy():
    img, d = canvas(VOID)
    d.rectangle([0, 0, W * SS, s(150)], fill=(19, 22, 28))
    caption(d, "No audio. No transcripts. No telemetry.",
            "One download, then it works with the network switched off.")

    panel(d, (150, 200, 1130, 640), radius=14)
    d.rectangle([s(150), s(214), s(153), s(626)], fill=OK)
    text(d, (186, 232), "What leaves this device", kind="sans_bold", size=17, fill=TEXT)

    facts = [
        ("Your audio", "Nothing. Microphone \u2192 AudioWorklet \u2192 local worker, then discarded."),
        ("Your transcripts", "Nothing. History stays in this browser profile, and you can switch it off."),
        ("Analytics", "None. There is no telemetry code in this extension."),
        ("Network", "One model download from huggingface.co. After that you can turn off Wi-Fi."),
    ]
    for i, (k, v) in enumerate(facts):
        y = 288 + i * 62
        lamp(d, (200, y + 8), OK)
        text(d, (218, y), k, kind="sans_bold", size=14, fill=TEXT)
        text(d, (218, y + 22), v, size=13, fill=DIM)

    panel(d, (186, 548, 1094, 608), fill=PANEL2, outline=LINE, radius=10)
    label(d, (206, 566), "Model cache")
    text(d, (206, 580), "148.3 MB across 6 files \u2014 onnx-community/whisper-base",
         size=13, fill=TEXT)
    panel(d, (940, 560, 1076, 596), fill=PANEL, outline=(74, 52, 48), radius=7)
    text(d, (1008, 578), "Delete models", size=12, fill=(227, 105, 95), anchor="mm")

    label(d, (64, H - 52), "3 / 5  \u00b7  settings \u203a storage & privacy")
    return finish(img, "3-privacy.png")


# ---------------------------------------------------------------------------
# 4. Model picker mid-download
# ---------------------------------------------------------------------------
def shot_models():
    img, d = canvas(VOID)
    d.rectangle([0, 0, W * SS, s(150)], fill=(19, 22, 28))
    caption(d, "Three models. Download once, keep forever.",
            "Tiny for speed, Base for everyday use, Small when accuracy matters most.")

    panel(d, (150, 200, 1130, 640), radius=14)
    text(d, (186, 232), "Model", kind="sans_bold", size=17, fill=TEXT)
    text(d, (186, 260), "Bigger models are more accurate and slower. Each one downloads once and then works offline.",
         size=13, fill=DIM)

    cards = [
        ("Tiny", "~78 MB \u00b7 39M", "Fastest. Good for short commands and clean audio.", 1, False),
        ("Base", "~148 MB \u00b7 74M", "The sweet spot. Recommended for everyday dictation.", 2, True),
        ("Small", "~490 MB \u00b7 244M", "Most accurate. Best with WebGPU and a discrete GPU.", 3, False),
    ]
    for i, (name, size_s, blurb, acc, active) in enumerate(cards):
        x0 = 186 + i * 306
        x1 = x0 + 282
        panel(d, (x0, 292, x1, 424),
              fill=(45, 36, 24) if active else PANEL2,
              outline=SIGNAL if active else LINE, radius=10)
        text(d, (x0 + 18, 310), name, kind="sans_bold", size=16, fill=TEXT)
        label(d, (x0 + 18, 338), size_s, fill=DIM)
        words, line, ly = blurb.split(), "", 358
        for wd in words:
            if len(line + wd) > 34:
                text(d, (x0 + 18, ly), line, size=12, fill=DIM); ly += 18; line = ""
            line += wd + " "
        text(d, (x0 + 18, ly), line, size=12, fill=DIM)
        for b in range(3):
            bx = x0 + 18 + b * 20
            d.rounded_rectangle([s(bx), s(404), s(bx + 15), s(407)], radius=s(1.5),
                                fill=SIGNAL if b < acc else PANEL3)

    button(d, (186, 452, 366, 492), "Download & load model", primary=True)
    panel(d, (382, 452, 542, 492), fill=PANEL2, outline=LINE, radius=7)
    text(d, (462, 472), "Unload from memory", size=12, fill=DIM, anchor="mm")

    # progress
    d.rounded_rectangle([s(186), s(524), s(1094), s(530)], radius=s(3), fill=PANEL3)
    d.rounded_rectangle([s(186), s(524), s(186 + int(908 * 0.62)), s(530)], radius=s(3), fill=SIGNAL)
    label(d, (186, 544), "92.1 MB of 148.3 MB", fill=DIM)

    panel(d, (186, 578, 1094, 616), fill=PANEL2, outline=LINE, radius=8)
    lamp(d, (208, 597), OK)
    text(d, (224, 589), "WebGPU is available. Whisper will run on your GPU, typically 3\u20138\u00d7 faster than CPU.",
         size=12, fill=DIM)

    label(d, (64, H - 52), "4 / 5  \u00b7 settings \u203a engine")
    return finish(img, "4-models.png")


# ---------------------------------------------------------------------------
# 5. Light theme
# ---------------------------------------------------------------------------
def shot_light():
    img, d = canvas(L_VOID)
    d.rectangle([0, 0, W * SS, s(150)], fill=(240, 242, 246))
    caption(d, "Dark or light. Yours to keep or export.",
            "Every transcript stays on your machine \u2014 copy it, export it, or clear it.",
            light=True)
    popup_panel(d, 462, 196, light=True, listening=False, level=0.0,
                transcript=["Move the review to Thursday and give",
                            "the team a proper heads-up. I'll circulate",
                            "the deck tomorrow morning."])
    text(d, (64, H - 52), "5 / 5  \u00b7  LIGHT THEME", kind="mono", size=9,
         fill=L_DIM, tracking=1.4)
    return finish(img, "5-light.png")


# ---------------------------------------------------------------------------
# Promo tile 440x280
# ---------------------------------------------------------------------------
def promo():
    pw, ph = 440, 280
    img = Image.new("RGB", (pw * SS, ph * SS), VOID)
    d = ImageDraw.Draw(img)
    d.rounded_rectangle([s(0), s(0), s(pw), s(ph)], fill=VOID)
    wordmark(d, (36, 40))
    text(d, (36, 92), "Speak freely.", kind="sans_bold", size=26, fill=TEXT)
    text(d, (36, 124), "Type instantly.", kind="sans_bold", size=26, fill=SIGNAL)
    text(d, (36, 168), "Private, offline voice typing", size=12, fill=DIM)
    text(d, (36, 186), "for Chrome. Free and open source.", size=12, fill=DIM)
    meter(d, (36, 222, 404, 244), 0.72, segments=28)
    out = img.resize((pw, ph), Image.LANCZOS).convert("RGB")
    out.save(PROMO, "PNG")
    print(f"  {PROMO.relative_to(PROMO.parent.parent.parent)}  {pw}x{ph} RGB")


def main():
    print("\n  Rendering Chrome Web Store assets\n")
    shots = [shot_popup(), shot_in_page(), shot_privacy(), shot_models(), shot_light()]
    promo()
    for shot in shots:
        assert shot.size == (W, H) and shot.mode == "RGB"
    print("\n  All assets are 1280x800 RGB with no alpha channel.")
    print("  Replace with real captures before publishing \u2014 see store/screenshots/README.md\n")


if __name__ == "__main__":
    main()
