#!/usr/bin/env node
/**
 * Pre-flight checks before loading unpacked or submitting to the Web Store.
 * Catches the failures that produce a silent, blank extension: a manifest
 * pointing at a file that moved, an import path off by one directory, an icon
 * that was never generated.
 *
 * Run with: npm run validate
 */

import { readFile, readdir, access, stat } from 'node:fs/promises';
import { constants } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

let failures = 0;
let checks = 0;

function ok(msg) {
  checks++;
  console.log(`  \u2713 ${msg}`);
}

function bad(msg) {
  checks++;
  failures++;
  console.log(`  \u2717 ${msg}`);
}

async function exists(rel) {
  try {
    await access(path.join(root, rel), constants.R_OK);
    return true;
  } catch {
    return false;
  }
}

async function walk(dir, out = []) {
  for (const entry of await readdir(path.join(root, dir), { withFileTypes: true })) {
    const rel = path.join(dir, entry.name);
    if (entry.isDirectory()) await walk(rel, out);
    else out.push(rel);
  }
  return out;
}

/* --------------------------- manifest references -------------------------- */

async function checkManifest(manifest) {
  console.log('\nManifest references');

  const refs = new Set();
  const collect = (value) => {
    if (typeof value === 'string') {
      if (/\.(js|html|css|png|svg|json)$/.test(value) && !value.startsWith('http')) refs.add(value);
    } else if (Array.isArray(value)) value.forEach(collect);
    else if (value && typeof value === 'object') Object.values(value).forEach(collect);
  };
  collect(manifest);

  for (const ref of [...refs].sort()) {
    if (ref.includes('*')) continue; // web_accessible_resources globs
    (await exists(ref)) ? ok(ref) : bad(`${ref} — referenced by manifest.json but missing`);
  }

  console.log('\nManifest sanity');
  manifest.manifest_version === 3 ? ok('manifest_version is 3') : bad('manifest_version must be 3');
  manifest.background?.type === 'module'
    ? ok('service worker is a module (ES imports will resolve)')
    : bad('background.type must be "module" — the service worker uses ES imports');

  const csp = manifest.content_security_policy?.extension_pages || '';
  csp.includes('wasm-unsafe-eval')
    ? ok("CSP allows 'wasm-unsafe-eval' — required by ONNX Runtime")
    : bad("CSP is missing 'wasm-unsafe-eval'; ONNX Runtime will refuse to start");

  manifest.permissions?.includes('offscreen')
    ? ok('offscreen permission present')
    : bad('offscreen permission missing — audio capture is impossible without it');

  const cmdCount = Object.keys(manifest.commands || {}).length;
  cmdCount <= 4
    ? ok(`${cmdCount} commands declared (Chrome allows 4)`)
    : bad(`${cmdCount} commands declared — Chrome allows a maximum of 4`);
}

/* ------------------------------ import graph ------------------------------ */

async function checkImports() {
  console.log('\nImport graph');
  const files = (await walk('src')).filter((f) => f.endsWith('.js'));
  const IMPORT_RE = /(?:^|\s)(?:import|export)[^'"]*?from\s+['"]([^'"]+)['"]/g;

  for (const file of files) {
    const source = await readFile(path.join(root, file), 'utf8');
    for (const [, spec] of source.matchAll(IMPORT_RE)) {
      if (!spec.startsWith('.')) {
        bad(`${file} imports bare specifier "${spec}" — browsers cannot resolve this`);
        continue;
      }
      const resolved = path.normalize(path.join(path.dirname(file), spec));
      (await exists(resolved))
        ? ok(`${file} → ${spec}`)
        : bad(`${file} imports "${spec}" which resolves to a missing ${resolved}`);
    }
  }
}

/* --------------------------- html asset references ------------------------ */

async function checkHtml() {
  console.log('\nHTML asset references');
  const pages = (await walk('src')).filter((f) => f.endsWith('.html'));
  const ASSET_RE = /(?:src|href)\s*=\s*["']([^"'#]+)["']/g;

  for (const page of pages) {
    const source = await readFile(path.join(root, page), 'utf8');
    for (const [, ref] of source.matchAll(ASSET_RE)) {
      if (/^(https?:|chrome:|data:|mailto:)/.test(ref)) continue;
      const resolved = path.normalize(path.join(path.dirname(page), ref));
      (await exists(resolved)) ? ok(`${page} → ${ref}`) : bad(`${page} references missing ${ref}`);
    }
  }
}

/* -------------------------------- runtime --------------------------------- */

async function checkVendored() {
  console.log('\nVendored runtime');
  if (await exists('lib/transformers.js')) {
    const size = (await stat(path.join(root, 'lib/transformers.js'))).size;
    size > 500_000
      ? ok(`lib/transformers.js present (${(size / 1e6).toFixed(1)} MB)`)
      : bad('lib/transformers.js looks truncated');
  } else {
    bad('lib/transformers.js missing — run `npm run build`');
  }

  const ortFiles = (await exists('lib/ort')) ? await readdir(path.join(root, 'lib/ort')) : [];
  ortFiles.some((f) => f.endsWith('.wasm'))
    ? ok(`lib/ort contains ${ortFiles.length} runtime files`)
    : bad('lib/ort has no .wasm — run `npm run build`');
}

/* -------------------------- restricted contexts --------------------------- */

/**
 * Offscreen documents and dedicated workers are granted `chrome.runtime` and
 * nothing else. Reaching for `chrome.storage` there throws at module
 * evaluation, which kills the whole audio engine before a single function
 * runs — and because it happens on import, a transitive dependency is enough
 * to do it. So we walk the real import graph from each entry point.
 */
async function checkRestrictedContexts() {
  console.log('\nRestricted-context API use');

  const ENTRIES = ['src/offscreen/offscreen.js', 'src/worker/whisper-worker.js'];
  const ALLOWED = new Set(['runtime']);
  const IMPORT_RE = /(?:^|\s)(?:import|export)[^'"]*?from\s+['"](\.[^'"]+)['"]/g;
  const CHROME_RE = /\bchrome\s*(?:\?\.)?\.\s*(\w+)/g;

  for (const entry of ENTRIES) {
    const seen = new Set();
    const queue = [entry];
    const offences = [];

    while (queue.length) {
      const file = queue.shift();
      if (seen.has(file) || !(await exists(file))) continue;
      seen.add(file);

      const raw = await readFile(path.join(root, file), 'utf8');
      // Strip comments first, or prose explaining the rule trips the rule.
      const source = raw.replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*\/\/.*$/gm, '');

      for (const [, api] of source.matchAll(CHROME_RE)) {
        if (!ALLOWED.has(api)) offences.push(`${file} uses chrome.${api}`);
      }
      for (const [, spec] of raw.matchAll(IMPORT_RE)) {
        queue.push(path.normalize(path.join(path.dirname(file), spec)));
      }
    }

    const reachable = [...seen].length;
    if (offences.length) {
      for (const offence of [...new Set(offences)]) {
        bad(`${offence} — only chrome.runtime exists in this context`);
      }
    } else {
      ok(`${entry} and its ${reachable - 1} dependencies use only chrome.runtime`);
    }
  }
}

/* ------------------------------ dead symbols ------------------------------ */

async function checkExportsUsed() {
  console.log('\nCross-module symbols');
  const constants = await readFile(path.join(root, 'src/common/constants.js'), 'utf8');
  const declared = [...constants.matchAll(/export const (\w+)/g)].map((m) => m[1]);
  const allSource = (
    await Promise.all(
      (await walk('src')).filter((f) => f.endsWith('.js')).map((f) => readFile(path.join(root, f), 'utf8'))
    )
  ).join('\n');

  for (const symbol of declared) {
    const uses = allSource.split(new RegExp(`\\b${symbol}\\b`)).length - 1;
    uses > 1 ? ok(`${symbol} used in ${uses - 1} place(s)`) : bad(`${symbol} is declared but never used`);
  }
}

/* ---------------------------------- run ----------------------------------- */

const manifest = JSON.parse(await readFile(path.join(root, 'manifest.json'), 'utf8'));

console.log(`\nLocalDictate v${manifest.version} — pre-flight\n${'─'.repeat(46)}`);
await checkManifest(manifest);
await checkImports();
await checkHtml();
await checkVendored();
await checkRestrictedContexts();
await checkExportsUsed();

console.log(`${'─'.repeat(46)}`);
if (failures) {
  console.log(`\n  ${failures} problem(s) across ${checks} checks.\n`);
  process.exit(1);
}
console.log(`\n  All ${checks} checks passed. Ready to load unpacked.\n`);
