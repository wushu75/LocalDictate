#!/usr/bin/env python3
"""
Generate LocalDictate's raster icons.

Design: a machined faceplate in near-black with an amber microphone capsule and
a three-segment level meter beneath it — the same signal lamp language used in
the popup. Small sizes drop the meter so the mic stays legible at 16 px.

Usage:  python3 scripts/make-icons.py
Output: icons/icon16.png, icon32.png, icon48.png, icon128.png, icon512.png
"""

from pathlib import Path
from PIL import Image, ImageDraw

OUT = Path(__file__).resolve().parent.parent / "icons"
OUT.mkdir(exist_ok=True)

PLATE = (21, 25, 32, 255)      # #151920
EDGE = (42, 48, 59, 255)       # #2A303B
AMBER = (242, 160, 61, 255)    # #F2A03D
AMBER_DIM = (122, 84, 36, 255)
SS = 8                          # supersampling factor


def draw_icon(size: int, with_meter: bool) -> Image.Image:
    s = size * SS
    img = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)

    # Faceplate
    radius = int(s * 0.235)
    d.rounded_rectangle([0, 0, s - 1, s - 1], radius=radius, fill=PLATE)
    d.rounded_rectangle(
        [int(s * 0.02), int(s * 0.02), s - 1 - int(s * 0.02), s - 1 - int(s * 0.02)],
        radius=int(radius * 0.92),
        outline=EDGE,
        width=max(1, int(s * 0.016)),
    )

    cx = s / 2
    top = s * (0.20 if with_meter else 0.22)
    cap_w = s * 0.235
    cap_h = s * (0.365 if with_meter else 0.40)

    # Microphone capsule
    d.rounded_rectangle(
        [cx - cap_w / 2, top, cx + cap_w / 2, top + cap_h],
        radius=cap_w / 2,
        fill=AMBER,
    )

    # Pickup arc
    lw = max(1, int(s * 0.055))
    arc_r = s * 0.205
    arc_cy = top + cap_h * 0.74
    d.arc(
        [cx - arc_r, arc_cy - arc_r, cx + arc_r, arc_cy + arc_r],
        start=15, end=165,
        fill=AMBER, width=lw,
    )

    # Stem
    stem_top = arc_cy + arc_r
    stem_bottom = stem_top + s * (0.075 if with_meter else 0.10)
    d.line([cx, stem_top, cx, stem_bottom], fill=AMBER, width=lw)

    # Level meter: three segments, brightest in the middle
    if with_meter:
        seg_w = s * 0.075
        seg_h = s * 0.048
        gap = s * 0.038
        y = s * 0.845
        colours = [AMBER_DIM, AMBER, AMBER_DIM]
        total = 3 * seg_w + 2 * gap
        x = cx - total / 2
        for colour in colours:
            d.rounded_rectangle(
                [x, y, x + seg_w, y + seg_h], radius=seg_h / 2, fill=colour
            )
            x += seg_w + gap

    return img.resize((size, size), Image.LANCZOS)


def main() -> None:
    for size in (16, 32, 48, 128, 512):
        icon = draw_icon(size, with_meter=size >= 48)
        path = OUT / f"icon{size}.png"
        icon.save(path)
        print(f"wrote {path.relative_to(OUT.parent)} ({path.stat().st_size} bytes)")


if __name__ == "__main__":
    main()
