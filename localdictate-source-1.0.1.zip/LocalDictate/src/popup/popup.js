import { MSG, STATE, MODELS, REPO_URL, STORE_URL } from '../common/constants.js';
import { getSettings, setSettings, getHistory } from '../common/storage.js';
import { formatBytes } from '../common/idb-cache.js';

const $ = (id) => document.getElementById(id);

const el = {
  lamp: $('lamp'),
  status: $('statusText'),
  device: $('deviceChip'),
  meter: $('meter'),
  hotkey: $('hotkeyHint'),
  stats: $('statsHint'),
  micBtn: $('micBtn'),
  micLabel: $('micBtnLabel'),
  transcript: $('transcript'),
  copyBtn: $('copyBtn'),
  exportBtn: $('exportBtn'),
  clearBtn: $('clearBtn'),
  modelSelect: $('modelSelect'),
  modelBlurb: $('modelBlurb'),
  loadBtn: $('loadBtn'),
  progressWrap: $('progressWrap'),
  progressFill: $('progressFill'),
  progressText: $('progressText'),
  alert: $('alert'),
  shareBtn: $('shareBtn'),
  repoLink: $('repoLink'),
  themeBtn: $('themeBtn'),
  optionsBtn: $('optionsBtn')
};

let settings = null;
let finals = [];
let liveLine = null;
let active = false;

const SEGMENTS = 24;
const bars = [];

/* ------------------------------- bootstrap -------------------------------- */

init().catch(showError);

async function init() {
  settings = await getSettings();
  applyTheme(settings.theme);

  for (let i = 0; i < SEGMENTS; i++) {
    const bar = document.createElement('i');
    el.meter.appendChild(bar);
    bars.push(bar);
  }

  el.repoLink.href = REPO_URL;
  el.modelSelect.value = settings.model;
  el.modelBlurb.textContent = MODELS[settings.model].blurb;

  const commands = await chrome.commands.getAll();
  const toggle = commands.find((c) => c.name === 'toggle-dictation');
  el.hotkey.textContent =
    settings.mode === 'push'
      ? `Hold ${prettyKey(settings.pushKey)}`
      : toggle?.shortcut || 'No hotkey set';

  finals = (await getHistory()).slice(0, 12).reverse();
  renderTranscript();

  const state = await send(MSG.GET_STATE);
  if (state?.ok) applyState(state.state, state);

  wireEvents();
}

function wireEvents() {
  el.micBtn.addEventListener('click', async () => {
    setBusy(true);
    await send(active ? MSG.STOP : MSG.START);
    setBusy(false);
  });

  el.modelSelect.addEventListener('change', async () => {
    const model = el.modelSelect.value;
    settings = await setSettings({ model });
    el.modelBlurb.textContent = MODELS[model].blurb;
    el.loadBtn.textContent = 'Load';
    el.loadBtn.disabled = false;
  });

  el.loadBtn.addEventListener('click', async () => {
    el.loadBtn.disabled = true;
    el.loadBtn.textContent = 'Loading…';
    showProgress(0, `Preparing ${MODELS[settings.model].label} (${MODELS[settings.model].downloadSize})`);
    await send(MSG.LOAD_MODEL, { force: true });
  });

  el.copyBtn.addEventListener('click', async () => {
    await navigator.clipboard.writeText(transcriptText());
    flash(el.copyBtn, 'Copied');
  });

  el.exportBtn.addEventListener('click', () => {
    const blob = new Blob([transcriptText()], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `localdictate-${new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-')}.txt`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
  });

  el.clearBtn.addEventListener('click', () => {
    finals = [];
    liveLine = null;
    renderTranscript();
  });

  el.shareBtn.addEventListener('click', share);

  el.themeBtn.addEventListener('click', async () => {
    const order = ['system', 'dark', 'light'];
    const next = order[(order.indexOf(settings.theme) + 1) % order.length];
    settings = await setSettings({ theme: next });
    applyTheme(next);
    flash(el.themeBtn, next === 'system' ? '◐' : next === 'dark' ? '☾' : '☀');
  });

  el.optionsBtn.addEventListener('click', () => chrome.runtime.openOptionsPage());

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.to !== 'popup') return;
    handle(msg);
  });
}

/* -------------------------------- messages -------------------------------- */

function send(type, payload = {}) {
  return chrome.runtime.sendMessage({ to: 'background', type, ...payload }).catch(() => null);
}

function handle(msg) {
  switch (msg.type) {
    case MSG.STATE:
      applyState(msg.state, msg);
      break;
    case MSG.LEVEL:
      paintMeter(msg.level, msg.voiced);
      break;
    case MSG.PARTIAL:
      liveLine = msg.text || null;
      renderTranscript();
      break;
    case MSG.FINAL:
      liveLine = null;
      if (msg.text) finals.push({ text: msg.text });
      el.stats.textContent = msg.ms ? `${(msg.seconds || 0).toFixed(1)}s in ${msg.ms}ms` : '';
      renderTranscript();
      break;
    case MSG.MODEL_PROGRESS:
      onProgress(msg);
      break;
    case MSG.MODEL_READY:
      hideProgress();
      el.loadBtn.textContent = 'Loaded';
      el.loadBtn.disabled = true;
      setDevice(msg.device);
      break;
    case MSG.ERROR:
      showError(msg.message, msg.level === 'notice' ? 'notice' : 'error', msg.code);
      break;
  }
}

/* --------------------------------- render --------------------------------- */

function applyState(state, extra = {}) {
  active = state === STATE.LISTENING || state === STATE.SPEAKING || state === STATE.TRANSCRIBING;
  el.lamp.dataset.state = state;
  el.status.textContent = {
    [STATE.IDLE]: 'Idle',
    [STATE.LOADING]: 'Loading model',
    [STATE.READY]: 'Ready',
    [STATE.LISTENING]: 'Listening',
    [STATE.SPEAKING]: 'Hearing you',
    [STATE.TRANSCRIBING]: 'Transcribing',
    [STATE.ERROR]: 'Something went wrong'
  }[state] || 'Idle';

  el.micLabel.textContent = active ? 'Stop dictating' : 'Start dictating';
  el.micBtn.classList.toggle('primary', !active);
  el.micBtn.classList.toggle('recording', active);

  if (extra.device) setDevice(extra.device);
  if (!active) paintMeter(0, false);
  if (state === STATE.READY || state === STATE.LISTENING) {
    el.loadBtn.textContent = 'Loaded';
    el.loadBtn.disabled = true;
  }
}

function setDevice(device) {
  if (!device) return;
  el.device.textContent = device === 'webgpu' ? 'WebGPU' : 'WASM';
  el.device.dataset.device = device;
  el.device.title =
    device === 'webgpu'
      ? 'Running on your GPU through WebGPU'
      : 'Running on the CPU through WebAssembly';
}

function paintMeter(level = 0, voiced = false) {
  const lit = Math.round(Math.min(1, level * 1.5) * SEGMENTS);
  for (let i = 0; i < SEGMENTS; i++) {
    const on = i < lit;
    bars[i].className = on ? (i > SEGMENTS - 3 ? 'hot' : voiced ? 'on' : '') : '';
    if (on && !voiced) bars[i].style.opacity = '0.4';
    else bars[i].style.opacity = '';
  }
}

function transcriptText() {
  return finals.map((f) => f.text).join(' ').trim();
}

function renderTranscript() {
  const hasText = finals.length > 0;
  el.copyBtn.disabled = !hasText;
  el.exportBtn.disabled = !hasText;
  el.clearBtn.disabled = !hasText;

  if (!hasText && !liveLine) {
    el.transcript.innerHTML =
      '<p class="empty">Put your caret in any text field, then start dictating. Words land where the caret is.</p>';
    return;
  }

  el.transcript.textContent = '';
  if (hasText) {
    const p = document.createElement('p');
    p.textContent = transcriptText();
    el.transcript.appendChild(p);
  }
  if (liveLine) {
    const p = document.createElement('p');
    p.className = 'live';
    p.textContent = liveLine;
    el.transcript.appendChild(p);
  }
  el.transcript.scrollTop = el.transcript.scrollHeight;
}

/* -------------------------------- progress -------------------------------- */

const files = new Map();

function onProgress(msg) {
  if (msg.status === 'progress' || msg.status === 'download' || msg.status === 'initiate') {
    files.set(msg.file, { loaded: msg.loaded || 0, total: msg.total || 0 });
  }
  if (msg.status === 'done') files.set(msg.file, { loaded: 1, total: 1 });

  let loaded = 0;
  let total = 0;
  for (const f of files.values()) {
    loaded += f.loaded;
    total += f.total;
  }
  const pct = total ? Math.min(100, (loaded / total) * 100) : 0;
  showProgress(pct, total ? `${formatBytes(loaded)} of ${formatBytes(total)}` : 'Preparing…');
}

function showProgress(pct, text) {
  el.progressWrap.hidden = false;
  el.progressFill.style.width = `${pct}%`;
  el.progressText.textContent = text;
}

function hideProgress() {
  el.progressWrap.hidden = true;
  files.clear();
}

/* --------------------------------- misc ----------------------------------- */

function showError(message, tone = 'error', code) {
  el.alert.hidden = false;
  el.alert.dataset.tone = tone;
  el.alert.textContent = typeof message === 'string' ? message : message?.message || 'Unexpected error.';
  if (code === 'mic-denied') {
    const btn = document.createElement('button');
    btn.className = 'btn tiny';
    btn.textContent = 'Grant microphone access';
    btn.addEventListener('click', () =>
      chrome.tabs.create({ url: chrome.runtime.getURL('src/permission/mic.html') })
    );
    el.alert.appendChild(btn);
  }
  setTimeout(() => {
    if (tone !== 'error') el.alert.hidden = true;
  }, 6000);
}

function setBusy(busy) {
  el.micBtn.disabled = busy;
}

function flash(node, text) {
  const original = node.textContent;
  node.textContent = text;
  setTimeout(() => (node.textContent = original), 1200);
}

function applyTheme(theme) {
  const resolved =
    theme === 'system'
      ? window.matchMedia('(prefers-color-scheme: light)').matches
        ? 'light'
        : 'dark'
      : theme;
  document.documentElement.dataset.theme = resolved;
}

function prettyKey(code) {
  return code
    .replace('ControlRight', 'Right Ctrl')
    .replace('ControlLeft', 'Left Ctrl')
    .replace('AltRight', 'Right Alt')
    .replace('AltLeft', 'Left Alt')
    .replace('ShiftRight', 'Right Shift')
    .replace('ShiftLeft', 'Left Shift');
}

async function share() {
  const message =
    `I've been using LocalDictate — free voice typing for Chrome that runs Whisper entirely on your own machine. ` +
    `No account, no upload, works offline once the model is downloaded.\n\n` +
    `Chrome Web Store: ${STORE_URL}\n` +
    `Source (MIT): ${REPO_URL}`;
  try {
    await navigator.clipboard.writeText(message);
    flash(el.shareBtn, 'Message copied');
  } catch {
    showError('Could not reach the clipboard. Copy the link from the GitHub button instead.', 'notice');
  }
}
