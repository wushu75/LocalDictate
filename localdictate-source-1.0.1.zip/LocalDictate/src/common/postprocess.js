/**
 * Text clean-up applied after Whisper decoding.
 * Deliberately conservative: it should never invent words, only tidy them.
 */

const FILLERS = [
  'um', 'umm', 'ummm', 'uh', 'uhh', 'uhm', 'erm', 'er', 'ah', 'ahh',
  'hmm', 'hm', 'mhm', 'mm', 'eh'
];

const FILLER_RE = new RegExp(
  `(^|[\\s,;:—-])(?:${FILLERS.join('|')})\\b[,.]?(?=\\s|$)`,
  'gi'
);

/** Spoken commands that map to characters. */
const DICTATION_COMMANDS = [
  [/\bnew paragraph\b[.,]?/gi, '\n\n'],
  [/\bnew line\b[.,]?/gi, '\n'],
  [/\bfull stop\b/gi, '.'],
  [/\bperiod\b(?=\s|$)/gi, '.'],
  [/\bcomma\b(?=\s|$)/gi, ','],
  [/\bquestion mark\b/gi, '?'],
  [/\bexclamation (?:mark|point)\b/gi, '!'],
  [/\bsemicolon\b/gi, ';'],
  [/\bcolon\b(?=\s|$)/gi, ':'],
  [/\bopen paren(?:thesis)?\b/gi, '('],
  [/\bclose paren(?:thesis)?\b/gi, ')']
];

/** Whisper emits these when it hears nothing but noise or music. */
const HALLUCINATION_RE =
  /^\s*(?:\[[^\]]*\]|\([^)]*\)|♪+|thanks? for watching[.!]?|thank you[.!]?|you|bye[.!]?|\.+)\s*$/i;

export function isNoiseOnly(text) {
  if (!text) return true;
  const stripped = text.replace(/[\s.,!?]/g, '');
  if (stripped.length === 0) return true;
  return HALLUCINATION_RE.test(text.trim());
}

function stripBracketedEvents(text) {
  // "[BLANK_AUDIO]", "(wind blowing)", "♪♪" and friends.
  return text
    .replace(/\[[^\]\n]{0,40}\]/g, ' ')
    .replace(/\([^)\n]{0,40}\)/g, (m) => (/[.?!]/.test(m) ? m : ' '))
    .replace(/♪/g, ' ');
}

/** Removing "uh" from "thinking, uh, we" leaves ", ," behind. Tidy that up. */
function collapsePunctuationRuns(text) {
  return text
    .replace(/([,;:])(\s*[,;:])+/g, '$1')
    .replace(/([.!?])\s*([,;:])/g, '$1')
    .replace(/^\s*[,;:]\s*/, '')
    .replace(/\s+([,;:])/g, '$1');
}

function collapseWhitespace(text) {
  return text
    .replace(/[ \t]+/g, ' ')
    .replace(/ ?\n ?/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

function fixPunctuationSpacing(text) {
  return text
    .replace(/\s+([,.;:!?%])/g, '$1')
    .replace(/([,;:])(?=\S)/g, '$1 ')
    .replace(/([.!?])(?=[A-Za-z0-9])/g, '$1 ')
    .replace(/\(\s+/g, '(')
    .replace(/\s+\)/g, ')');
}

function capitalizeSentences(text) {
  let out = text.replace(/(^|[.!?]\s+|\n\s*)([a-z])/g, (_, lead, ch) => lead + ch.toUpperCase());
  out = out.replace(/\bi\b/g, 'I').replace(/\bi'(m|ve|ll|d)\b/g, "I'$1");
  return out;
}

function applyReplacements(text, replacements = []) {
  let out = text;
  for (const rule of replacements) {
    if (!rule || !rule.from) continue;
    try {
      const pattern = rule.regex
        ? new RegExp(rule.from, 'gi')
        : new RegExp(`\\b${escapeRegExp(rule.from)}\\b`, 'gi');
      out = out.replace(pattern, rule.to ?? '');
    } catch {
      /* a malformed user rule should never break dictation */
    }
  }
  return out;
}

function escapeRegExp(s) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * @param {string} raw Whisper output for one utterance.
 * @param {object} settings LocalDictate settings object.
 * @returns {string} text ready to type into the page.
 */
export function postProcess(raw, settings = {}) {
  if (!raw) return '';
  let text = stripBracketedEvents(String(raw));

  for (const [re, rep] of DICTATION_COMMANDS) text = text.replace(re, rep);
  if (settings.removeFillers) text = collapsePunctuationRuns(text.replace(FILLER_RE, '$1'));

  text = applyReplacements(text, settings.customReplacements);
  text = collapseWhitespace(text);

  if (settings.smartPunctuation) text = fixPunctuationSpacing(text);
  if (settings.autoCapitalize) text = capitalizeSentences(text);

  if (settings.trailingPunctuation && text && !/[.!?,:;\n]$/.test(text)) text += '.';

  return collapseWhitespace(text);
}

export const __test__ = { FILLER_RE, DICTATION_COMMANDS };
