/**
 * IndexedDB model cache.
 *
 * Transformers.js accepts a custom cache that quacks like the Cache API
 * (`match(request)` / `put(request, response)`). We use IndexedDB rather than
 * Cache Storage so weights survive "clear browsing data → cached files" and so
 * the extension can report and clear its own footprint precisely.
 */

import { IDB_NAME, IDB_STORE } from './constants.js';

const VERSION = 1;
let dbPromise = null;

function openDB() {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    const req = indexedDB.open(IDB_NAME, VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(IDB_STORE)) {
        db.createObjectStore(IDB_STORE, { keyPath: 'url' });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
  return dbPromise;
}

function tx(mode) {
  return openDB().then((db) => db.transaction(IDB_STORE, mode).objectStore(IDB_STORE));
}

function wrap(request) {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

function keyOf(request) {
  return typeof request === 'string' ? request : request.url;
}

export const idbCache = {
  async match(request) {
    try {
      const store = await tx('readonly');
      const row = await wrap(store.get(keyOf(request)));
      if (!row) return undefined;
      return new Response(row.buffer, {
        headers: { 'Content-Type': row.type || 'application/octet-stream' }
      });
    } catch {
      return undefined;
    }
  },

  async put(request, response) {
    try {
      const buffer = await response.clone().arrayBuffer();
      const store = await tx('readwrite');
      await wrap(
        store.put({
          url: keyOf(request),
          buffer,
          type: response.headers.get('Content-Type') || 'application/octet-stream',
          size: buffer.byteLength,
          savedAt: Date.now()
        })
      );
    } catch (err) {
      console.warn('[LocalDictate] Could not cache model file:', err);
    }
  }
};

/** Total bytes and file count currently held on disk. */
export async function cacheInfo() {
  try {
    const store = await tx('readonly');
    const rows = await wrap(store.getAll());
    const bytes = rows.reduce((sum, r) => sum + (r.size || 0), 0);
    const models = new Set(
      rows.map((r) => {
        const m = /\/([^/]+\/[^/]+)\/resolve\//.exec(r.url) || /models\/([^/]+\/[^/]+)\//.exec(r.url);
        return m ? m[1] : 'unknown';
      })
    );
    return { files: rows.length, bytes, models: [...models] };
  } catch {
    return { files: 0, bytes: 0, models: [] };
  }
}

export async function clearCache() {
  const store = await tx('readwrite');
  await wrap(store.clear());
  try {
    // Also drop anything Transformers.js may have written to Cache Storage.
    const keys = await caches.keys();
    await Promise.all(keys.filter((k) => k.startsWith('transformers')).map((k) => caches.delete(k)));
  } catch {
    /* Cache Storage is optional */
  }
  return true;
}

export function formatBytes(bytes) {
  if (!bytes) return '0 MB';
  const mb = bytes / 1024 / 1024;
  return mb >= 1024 ? `${(mb / 1024).toFixed(2)} GB` : `${mb.toFixed(1)} MB`;
}
