/**
 * LocalDictate — shared constants.
 * Every value here is used on-device only. Nothing in this file points at an
 * analytics, telemetry or transcription server, because there isn't one.
 */

export const REPO_URL = 'https://github.com/wushu75/LocalDictate';
export const STORE_URL =
  'https://chromewebstore.google.com/detail/localdictate/REPLACE_WITH_STORE_ID';

/** Whisper checkpoints, ONNX-converted, fetched once from Hugging Face. */
export const MODELS = {
  tiny: {
    key: 'tiny',
    id: 'onnx-community/whisper-tiny',
    label: 'Tiny',
    blurb: 'Fastest. Good for short commands and clean audio.',
    downloadSize: '~78 MB',
    params: '39M',
    speed: 3,
    accuracy: 1
  },
  base: {
    key: 'base',
    id: 'onnx-community/whisper-base',
    label: 'Base',
    blurb: 'The sweet spot. Recommended for everyday dictation.',
    downloadSize: '~148 MB',
    params: '74M',
    speed: 2,
    accuracy: 2
  },
  small: {
    key: 'small',
    id: 'onnx-community/whisper-small',
    label: 'Small',
    blurb: 'Most accurate. Best with WebGPU and a discrete GPU.',
    downloadSize: '~490 MB',
    params: '244M',
    speed: 1,
    accuracy: 3
  }
};

export const LANGUAGES = [
  ['auto', 'Detect automatically'],
  ['en', 'English'],
  ['es', 'Spanish'],
  ['fr', 'French'],
  ['de', 'German'],
  ['it', 'Italian'],
  ['pt', 'Portuguese'],
  ['nl', 'Dutch'],
  ['pl', 'Polish'],
  ['ru', 'Russian'],
  ['uk', 'Ukrainian'],
  ['tr', 'Turkish'],
  ['ar', 'Arabic'],
  ['hi', 'Hindi'],
  ['zh', 'Chinese'],
  ['ja', 'Japanese'],
  ['ko', 'Korean'],
  ['vi', 'Vietnamese'],
  ['id', 'Indonesian'],
  ['sv', 'Swedish'],
  ['da', 'Danish'],
  ['no', 'Norwegian'],
  ['fi', 'Finnish'],
  ['cs', 'Czech'],
  ['el', 'Greek'],
  ['he', 'Hebrew'],
  ['ro', 'Romanian'],
  ['hu', 'Hungarian'],
  ['th', 'Thai']
];

export const DEFAULT_SETTINGS = {
  model: 'base',
  language: 'auto',
  device: 'auto', // auto | webgpu | wasm
  theme: 'system', // system | dark | light

  // Dictation behaviour
  mode: 'toggle', // toggle | push
  pushKey: 'ControlRight', // held key for push-to-talk (event.code)
  insertMode: 'auto', // auto | clipboard
  autoSpace: true,
  showHud: true,
  playSounds: true,

  // Voice activity detection
  vadEnabled: true,
  vadThreshold: 0.012, // RMS gate
  silenceMs: 700, // silence needed to close an utterance
  maxUtteranceMs: 22000,
  partialIntervalMs: 1400,

  // Post-processing
  removeFillers: true,
  autoCapitalize: true,
  smartPunctuation: true,
  trailingPunctuation: false,
  customReplacements: [], // [{ from, to, regex? }]

  // History
  keepHistory: true,
  historyLimit: 100
};

/** Message envelope types. `to` is one of: background | offscreen | popup | content */
export const MSG = {
  // control
  START: 'start',
  STOP: 'stop',
  CANCEL: 'cancel',
  TOGGLE: 'toggle',
  // model lifecycle
  LOAD_MODEL: 'load-model',
  UNLOAD_MODEL: 'unload-model',
  MODEL_PROGRESS: 'model-progress',
  MODEL_READY: 'model-ready',
  // audio + text
  LEVEL: 'level',
  PARTIAL: 'partial',
  FINAL: 'final',
  INSERT: 'insert',
  // status
  STATE: 'state',
  GET_STATE: 'get-state',
  GET_SETTINGS: 'get-settings',
  ERROR: 'error',
  CAPS: 'capabilities',
  // storage-side helpers
  CLEAR_CACHE: 'clear-cache',
  CACHE_INFO: 'cache-info'
};

/** High-level engine states surfaced in the UI. */
export const STATE = {
  IDLE: 'idle',
  LOADING: 'loading',
  READY: 'ready',
  LISTENING: 'listening',
  SPEAKING: 'speaking',
  TRANSCRIBING: 'transcribing',
  ERROR: 'error'
};

export const SAMPLE_RATE = 16000;
export const OFFSCREEN_PATH = 'src/offscreen/offscreen.html';
export const MIC_PERMISSION_PATH = 'src/permission/mic.html';
export const IDB_NAME = 'localdictate-models';
export const IDB_STORE = 'files';
