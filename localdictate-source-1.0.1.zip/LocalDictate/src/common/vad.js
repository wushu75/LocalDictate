/**
 * Voice activity detection.
 *
 * Energy gate with an adaptive noise floor and a hangover window. It runs on
 * 16 kHz mono frames of 128–2048 samples and costs microseconds, which keeps
 * the audio thread free for the model. It is not trying to be Silero — it is
 * trying to stop us transcribing your air conditioning.
 */

export class VAD {
  /**
   * @param {object} opts
   * @param {number} opts.sampleRate
   * @param {number} opts.threshold Base RMS gate (0–1).
   * @param {number} opts.silenceMs Silence needed before an utterance closes.
   * @param {number} opts.speechMs Speech needed before an utterance opens.
   */
  constructor({ sampleRate = 16000, threshold = 0.012, silenceMs = 700, speechMs = 160 } = {}) {
    this.sampleRate = sampleRate;
    this.threshold = threshold;
    this.silenceMs = silenceMs;
    this.speechMs = speechMs;

    this.noiseFloor = 0.003;
    this.speaking = false;
    this.speechRun = 0; // ms of consecutive voiced audio
    this.silenceRun = 0; // ms of consecutive unvoiced audio
    this.level = 0; // smoothed level for the meter (0–1)
  }

  reset() {
    this.speaking = false;
    this.speechRun = 0;
    this.silenceRun = 0;
    this.level = 0;
  }

  configure({ threshold, silenceMs }) {
    if (typeof threshold === 'number') this.threshold = threshold;
    if (typeof silenceMs === 'number') this.silenceMs = silenceMs;
  }

  /**
   * @param {Float32Array} frame
   * @returns {{voiced:boolean, level:number, started:boolean, ended:boolean}}
   */
  process(frame) {
    const ms = (frame.length / this.sampleRate) * 1000;

    let sum = 0;
    for (let i = 0; i < frame.length; i++) sum += frame[i] * frame[i];
    const rms = Math.sqrt(sum / frame.length);

    // Meter uses a fast attack / slow release so the bar feels alive.
    const scaled = Math.min(1, rms / 0.25);
    this.level = scaled > this.level ? scaled : this.level * 0.82 + scaled * 0.18;

    const gate = Math.max(this.threshold, this.noiseFloor * 2.6);
    const voiced = rms > gate;

    if (voiced) {
      this.speechRun += ms;
      this.silenceRun = 0;
    } else {
      this.silenceRun += ms;
      this.speechRun = 0;
      // Only learn the floor from quiet audio, and only slowly.
      this.noiseFloor = this.noiseFloor * 0.995 + rms * 0.005;
    }

    let started = false;
    let ended = false;

    if (!this.speaking && voiced && this.speechRun >= this.speechMs) {
      this.speaking = true;
      started = true;
    } else if (this.speaking && !voiced && this.silenceRun >= this.silenceMs) {
      this.speaking = false;
      ended = true;
    }

    return { voiced, level: this.level, started, ended, rms };
  }
}
