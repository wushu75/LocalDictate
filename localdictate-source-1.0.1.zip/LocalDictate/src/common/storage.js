import { DEFAULT_SETTINGS } from './constants.js';

/**
 * Resolved lazily, never at module scope. Offscreen documents and workers are
 * only granted `chrome.runtime`, so evaluating `chrome.storage.local` on
 * import would throw before any of these functions could be called — taking
 * the whole audio engine down with it. Those contexts must ask the service
 * worker for settings instead of importing this module.
 */
function area() {
  const local = globalThis.chrome?.storage?.local;
  if (!local) {
    throw new Error(
      'chrome.storage is unavailable here. Offscreen documents and workers should ' +
        "request settings from the service worker via { to: 'background', type: 'get-settings' }."
    );
  }
  return local;
}

export async function getSettings() {
  const stored = await area().get('settings');
  return { ...DEFAULT_SETTINGS, ...(stored.settings || {}) };
}

export async function setSettings(patch) {
  const current = await getSettings();
  const next = { ...current, ...patch };
  await area().set({ settings: next });
  return next;
}

export async function resetSettings() {
  await area().set({ settings: { ...DEFAULT_SETTINGS } });
  return { ...DEFAULT_SETTINGS };
}

export function onSettingsChanged(handler) {
  const listener = (changes, area) => {
    if (area !== 'local' || !changes.settings) return;
    handler({ ...DEFAULT_SETTINGS, ...(changes.settings.newValue || {}) });
  };
  chrome.storage.onChanged.addListener(listener);
  return () => chrome.storage.onChanged.removeListener(listener);
}

/* ------------------------------- history -------------------------------- */

export async function getHistory() {
  const { history } = await area().get('history');
  return Array.isArray(history) ? history : [];
}

export async function addHistoryEntry(entry) {
  const settings = await getSettings();
  if (!settings.keepHistory) return;
  const history = await getHistory();
  history.unshift({ text: entry.text, at: Date.now(), model: entry.model, ms: entry.ms });
  await area().set({ history: history.slice(0, settings.historyLimit) });
}

export async function clearHistory() {
  await area().remove('history');
}
