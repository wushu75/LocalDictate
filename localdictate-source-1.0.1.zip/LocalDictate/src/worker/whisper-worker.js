/**
 * LocalDictate inference worker.
 *
 * Owns the Whisper pipeline and nothing else. It receives Float32 PCM at
 * 16 kHz and returns text. It has no network access beyond the one-time model
 * download from Hugging Face, and no message path back to any server.
 */

import {
  pipeline,
  env,
  TextStreamer,
  InterruptableStoppingCriteria
} from '../../lib/transformers.js';
import { idbCache } from '../common/idb-cache.js';

let transcriber = null;
let activeDevice = null;
let activeModelId = null;
let generation = 0; // bumped on cancel so stale results are dropped
let stopper = null;  // lets a cancel actually halt decoding, not just ignore it
let busy = false;

const post = (msg, transfer = []) => self.postMessage(msg, transfer);

/* ------------------------------- setup ---------------------------------- */

function configureEnv({ wasmBase }) {
  env.allowLocalModels = false;
  env.allowRemoteModels = true;
  env.useBrowserCache = false;
  env.useCustomCache = true;
  env.customCache = idbCache;

  if (env.backends?.onnx?.wasm) {
    // Ship the runtime with the extension so an offline user is never stuck
    // waiting on a CDN.
    env.backends.onnx.wasm.wasmPaths = wasmBase;
    env.backends.onnx.wasm.numThreads = 1; // extension pages are not cross-origin isolated
    env.backends.onnx.wasm.proxy = false;
  }
}

async function detectWebGPU() {
  try {
    if (!('gpu' in navigator)) return false;
    const adapter = await navigator.gpu.requestAdapter();
    return !!adapter;
  } catch {
    return false;
  }
}

function dtypeFor(device, modelKey) {
  if (device === 'webgpu') {
    return { encoder_model: 'fp32', decoder_model_merged: modelKey === 'small' ? 'q4' : 'fp32' };
  }
  return { encoder_model: 'q8', decoder_model_merged: 'q8' };
}

async function load({ modelId, modelKey, device, wasmBase }) {
  configureEnv({ wasmBase });

  let target = device;
  if (target === 'auto') target = (await detectWebGPU()) ? 'webgpu' : 'wasm';
  if (target === 'webgpu' && !(await detectWebGPU())) {
    post({ type: 'notice', code: 'no-webgpu', message: 'WebGPU is unavailable. Falling back to WASM.' });
    target = 'wasm';
  }

  const build = async (dev) => {
    post({ type: 'status', stage: 'loading', device: dev });
    return pipeline('automatic-speech-recognition', modelId, {
      device: dev,
      dtype: dtypeFor(dev, modelKey),
      progress_callback: (p) => post({ type: 'progress', ...p })
    });
  };

  try {
    transcriber = await build(target);
    activeDevice = target;
  } catch (err) {
    if (target === 'webgpu') {
      post({
        type: 'notice',
        code: 'webgpu-failed',
        message: `WebGPU could not start (${err?.message || err}). Retrying on WASM.`
      });
      transcriber = await build('wasm');
      activeDevice = 'wasm';
    } else {
      throw err;
    }
  }

  activeModelId = modelId;

  // One silent pass so the first real utterance isn't paying compile costs.
  try {
    await transcriber(new Float32Array(16000), { language: 'en', task: 'transcribe' });
  } catch {
    /* warm-up is best effort */
  }

  post({ type: 'ready', device: activeDevice, modelId });
}

/* ---------------------------- transcription ------------------------------ */

async function transcribe({ id, audio, language, partial }) {
  if (!transcriber) {
    post({ type: 'error', id, message: 'Model is not loaded yet.' });
    return;
  }
  if (busy) {
    // Partials are disposable; finals are not, so a final never reaches here
    // (the offscreen document queues them).
    post({ type: 'skipped', id });
    return;
  }

  const myGeneration = generation;
  busy = true;
  const started = performance.now();

  stopper = new InterruptableStoppingCriteria();
  const options = {
    task: 'transcribe',
    return_timestamps: false,
    stopping_criteria: stopper
  };
  if (language && language !== 'auto') options.language = language;

  const seconds = audio.length / 16000;
  if (seconds > 30) {
    options.chunk_length_s = 30;
    options.stride_length_s = 5;
  }

  if (!partial) {
    let acc = '';
    options.streamer = new TextStreamer(transcriber.tokenizer, {
      skip_prompt: true,
      skip_special_tokens: true,
      callback_function: (text) => {
        if (myGeneration !== generation) return;
        acc += text;
        post({ type: 'partial', id, text: acc });
      }
    });
  }

  try {
    const output = await transcriber(audio, options);
    if (myGeneration !== generation) {
      post({ type: 'dropped', id });
      return;
    }
    const text = (Array.isArray(output) ? output[0]?.text : output?.text) || '';
    post({
      type: partial ? 'partial' : 'result',
      id,
      text: text.trim(),
      ms: Math.round(performance.now() - started),
      seconds: +seconds.toFixed(2),
      device: activeDevice
    });
  } catch (err) {
    post({ type: 'error', id, message: err?.message || String(err) });
  } finally {
    busy = false;
    stopper = null;
  }
}

/* ------------------------------ messaging -------------------------------- */

self.onmessage = async (event) => {
  const msg = event.data;
  try {
    switch (msg.type) {
      case 'init':
        await load(msg);
        break;
      case 'transcribe':
        await transcribe(msg);
        break;
      case 'cancel':
        generation++;
        stopper?.interrupt();
        break;
      case 'dispose':
        generation++;
        stopper?.interrupt();
        try {
          await transcriber?.dispose?.();
        } catch {
          /* ignore */
        }
        transcriber = null;
        activeDevice = null;
        activeModelId = null;
        post({ type: 'disposed' });
        break;
      case 'ping':
        post({ type: 'pong', loaded: !!transcriber, device: activeDevice, modelId: activeModelId });
        break;
    }
  } catch (err) {
    post({ type: 'error', id: msg?.id, message: err?.message || String(err) });
  }
};
