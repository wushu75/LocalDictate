/**
 * LocalDictate content script.
 *
 * Three jobs: remember where the caret is, show the listening HUD, and type
 * the finished text into the page. It never reads page content and never
 * sends anything anywhere except the extension itself.
 */
(() => {
  if (window.__localDictateLoaded) return;
  window.__localDictateLoaded = true;

  const IS_TOP = window.top === window;
  const MSG = {
    STATE: 'state',
    LEVEL: 'level',
    PARTIAL: 'partial',
    INSERT: 'insert',
    ERROR: 'error',
    TOGGLE: 'toggle',
    START: 'start',
    STOP: 'stop'
  };

  let settings = { showHud: true, mode: 'toggle', pushKey: 'ControlRight', autoSpace: true };
  let lastEditable = null;
  let hud = null;
  let hudEls = null;
  let hideTimer = null;
  let pushHeld = false;

  chrome.storage.local.get('settings').then(({ settings: s }) => {
    if (s) settings = { ...settings, ...s };
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.settings?.newValue) {
      settings = { ...settings, ...changes.settings.newValue };
    }
  });

  /* --------------------------- focus tracking --------------------------- */

  function deepActiveElement(root = document) {
    let el = root.activeElement;
    while (el?.shadowRoot?.activeElement) el = el.shadowRoot.activeElement;
    return el;
  }

  function isEditable(el) {
    if (!el || el.nodeType !== 1) return false;
    if (el.isContentEditable) return true;
    const tag = el.tagName;
    if (tag === 'TEXTAREA') return !el.disabled && !el.readOnly;
    if (tag === 'INPUT') {
      const type = (el.getAttribute('type') || 'text').toLowerCase();
      const typeable = ['text', 'search', 'url', 'email', 'tel', 'number', 'password', ''];
      return typeable.includes(type) && !el.disabled && !el.readOnly;
    }
    return false;
  }

  function rememberFocus() {
    const el = deepActiveElement();
    if (isEditable(el)) lastEditable = el;
  }

  document.addEventListener('focusin', rememberFocus, true);
  document.addEventListener('pointerdown', () => setTimeout(rememberFocus, 0), true);
  rememberFocus();

  /* ---------------------------- push to talk ---------------------------- */

  window.addEventListener(
    'keydown',
    (e) => {
      if (settings.mode !== 'push' || pushHeld) return;
      if (e.code !== settings.pushKey) return;
      pushHeld = true;
      rememberFocus();
      send(MSG.START);
    },
    true
  );

  window.addEventListener(
    'keyup',
    (e) => {
      if (!pushHeld || e.code !== settings.pushKey) return;
      pushHeld = false;
      send(MSG.STOP);
    },
    true
  );

  window.addEventListener('blur', () => {
    if (pushHeld) {
      pushHeld = false;
      send(MSG.STOP);
    }
  });

  function send(type, payload = {}) {
    chrome.runtime.sendMessage({ to: 'background', type, ...payload }).catch(() => {});
  }

  /* ------------------------------- the HUD ------------------------------ */

  function buildHud() {
    if (hud || !IS_TOP) return;
    hud = document.createElement('div');
    hud.className = 'ld-hud';
    hud.setAttribute('role', 'status');
    hud.setAttribute('aria-live', 'polite');

    const meter = document.createElement('div');
    meter.className = 'ld-meter';
    for (let i = 0; i < 14; i++) meter.appendChild(document.createElement('i'));

    hud.innerHTML = `
      <span class="ld-lamp" data-state="idle"></span>
      <span class="ld-label">On device</span>
    `;
    hud.appendChild(meter);

    const text = document.createElement('span');
    text.className = 'ld-text';
    text.textContent = 'Listening…';
    hud.appendChild(text);

    const stop = document.createElement('button');
    stop.className = 'ld-stop';
    stop.type = 'button';
    stop.textContent = 'Stop';
    stop.addEventListener('click', () => send(MSG.STOP));
    hud.appendChild(stop);

    (document.body || document.documentElement).appendChild(hud);
    hudEls = { meter: [...meter.children], lamp: hud.querySelector('.ld-lamp'), text };
  }

  function showHud(state) {
    if (!settings.showHud || !IS_TOP) return;
    buildHud();
    clearTimeout(hideTimer);
    hud.classList.add('ld-visible');
    hudEls.lamp.dataset.state = state;
    if (state === 'loading') hudEls.text.textContent = 'Loading the model…';
    if (state === 'listening') hudEls.text.textContent = 'Listening…';
    if (state === 'transcribing') hudEls.text.textContent = 'Transcribing…';
  }

  function hideHud() {
    if (!hud) return;
    hideTimer = setTimeout(() => hud.classList.remove('ld-visible'), 900);
  }

  function paintMeter(level, voiced) {
    if (!hudEls) return;
    const lit = Math.round(Math.min(1, level * 1.6) * hudEls.meter.length);
    hudEls.meter.forEach((bar, i) => {
      bar.className = i < lit ? (voiced ? 'on' : 'idle-on') : '';
    });
  }

  function toast(message, tone = 'info') {
    if (!IS_TOP) return;
    const el = document.createElement('div');
    el.className = `ld-toast ld-toast--${tone}`;
    el.textContent = message;
    (document.body || document.documentElement).appendChild(el);
    requestAnimationFrame(() => el.classList.add('ld-visible'));
    setTimeout(() => {
      el.classList.remove('ld-visible');
      setTimeout(() => el.remove(), 300);
    }, 4200);
  }

  /* ----------------------------- insertion ------------------------------ */

  function needsLeadingSpace(before, text) {
    if (!settings.autoSpace || !before) return false;
    if (/\s$/.test(before)) return false;
    if (/^[.,!?;:)\]]/.test(text)) return false;
    if (/[([{"'\u2018\u201c]$/.test(before)) return false;
    return true;
  }

  function insertIntoField(el, text) {
    const start = el.selectionStart ?? el.value.length;
    const end = el.selectionEnd ?? el.value.length;
    const before = el.value.slice(0, start);
    const payload = (needsLeadingSpace(before, text) ? ' ' : '') + text;

    const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement : HTMLInputElement;
    const setter = Object.getOwnPropertyDescriptor(proto.prototype, 'value').set;
    setter.call(el, before + payload + el.value.slice(end));

    const caret = start + payload.length;
    el.setSelectionRange(caret, caret);
    el.dispatchEvent(new InputEvent('input', { bubbles: true, data: payload, inputType: 'insertText' }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    return true;
  }

  function insertIntoContentEditable(el, text) {
    el.focus({ preventScroll: true });
    const sel = window.getSelection();
    let before = '';
    if (sel && sel.rangeCount) {
      const probe = sel.getRangeAt(0).cloneRange();
      probe.collapse(true);
      probe.setStart(el, 0);
      before = probe.toString();
    }
    const payload = (needsLeadingSpace(before, text) ? ' ' : '') + text;

    // execCommand still produces the correct undo stack and framework events
    // in Chrome; the Range path is the fallback for editors that block it.
    const ok = document.execCommand('insertText', false, payload);
    if (!ok && sel && sel.rangeCount) {
      const range = sel.getRangeAt(0);
      range.deleteContents();
      const node = document.createTextNode(payload);
      range.insertNode(node);
      range.setStartAfter(node);
      range.collapse(true);
      sel.removeAllRanges();
      sel.addRange(range);
      el.dispatchEvent(new InputEvent('input', { bubbles: true, data: payload, inputType: 'insertText' }));
    }
    return true;
  }

  async function copyFallback(text) {
    try {
      await navigator.clipboard.writeText(text);
      toast('Copied to clipboard — press Ctrl/Cmd+V to paste it here.', 'warn');
    } catch {
      toast('This editor blocks typing. Open LocalDictate to copy the text.', 'warn');
    }
  }

  function handleInsert(text, opts) {
    const el = lastEditable;
    const active = deepActiveElement();
    const targetIsHere = el && el.isConnected && (el === active || el.contains(active));

    if (!targetIsHere) return false; // another frame owns the caret

    if (opts.insertMode === 'clipboard') {
      copyFallback(text);
      return true;
    }

    try {
      if (el.isContentEditable) return insertIntoContentEditable(el, text);
      return insertIntoField(el, text);
    } catch (err) {
      console.warn('[LocalDictate] insertion failed, using clipboard', err);
      copyFallback(text);
      return true;
    }
  }

  /* ------------------------------ messages ------------------------------ */

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg?.to !== 'content') return false;

    switch (msg.type) {
      case MSG.STATE:
        if (msg.state === 'idle' || msg.state === 'ready' || msg.state === 'error') hideHud();
        else showHud(msg.state);
        sendResponse({ ok: true });
        break;

      case MSG.LEVEL:
        paintMeter(msg.level || 0, !!msg.voiced);
        sendResponse({ ok: true });
        break;

      case MSG.PARTIAL:
        if (hudEls && msg.text) {
          hudEls.text.textContent = msg.text.length > 90 ? '…' + msg.text.slice(-90) : msg.text;
        }
        sendResponse({ ok: true });
        break;

      case MSG.INSERT: {
        const inserted = handleInsert(msg.text, msg);
        if (inserted && hudEls) hudEls.text.textContent = 'Listening…';
        if (!inserted && IS_TOP && !lastEditable) {
          copyFallback(msg.text);
          sendResponse({ ok: true, inserted: false, copied: true });
          break;
        }
        sendResponse({ ok: true, inserted });
        break;
      }

      case MSG.ERROR:
        if (msg.level !== 'notice') hideHud();
        toast(msg.message, msg.level === 'notice' ? 'info' : 'error');
        sendResponse({ ok: true });
        break;

      default:
        sendResponse({ ok: false });
    }
    return true;
  });
})();
