/**
 * LocalDictate audio engine (offscreen document).
 *
 * Captures the microphone, segments it with VAD, and streams segments to the
 * inference worker. Audio buffers never leave this document except as
 * Float32Arrays passed to a same-origin worker.
 */

import { MSG, STATE, MODELS, SAMPLE_RATE } from '../common/constants.js';
import { VAD } from '../common/vad.js';

/**
 * This document is granted `chrome.runtime` and nothing else — no
 * chrome.storage — so settings arrive by message. The service worker attaches
 * them to every start/load, and this is the fallback for the rare path that
 * doesn't.
 */
async function fetchSettings() {
  const res = await chrome.runtime.sendMessage({ to: 'background', type: MSG.GET_SETTINGS });
  if (!res?.settings) throw new Error('Could not read settings from the service worker.');
  return res.settings;
}

const state = {
  engine: STATE.IDLE,
  settings: null,
  stream: null,
  audioCtx: null,
  node: null,
  source: null,
  worker: null,
  workerReady: false,
  loadedModel: null,
  loadedDevice: null,
  vad: null,
  utterance: [], // Float32Array chunks for the current utterance
  utteranceSamples: 0,
  lastPartialAt: 0,
  seq: 0,
  pendingFinal: null,
  levelSentAt: 0,
  loading: false
};

/* ----------------------------- messaging --------------------------------- */

function toBackground(type, payload = {}) {
  chrome.runtime.sendMessage({ to: 'background', type, ...payload }).catch(() => {});
}

function setEngineState(next, extra = {}) {
  state.engine = next;
  toBackground(MSG.STATE, { state: next, ...extra });
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.to !== 'offscreen') return false;

  (async () => {
    switch (msg.type) {
      case MSG.START:
        await start(msg.settings);
        sendResponse({ ok: true, state: state.engine });
        break;
      case MSG.STOP:
        await stop({ flush: true });
        sendResponse({ ok: true });
        break;
      case MSG.CANCEL:
        await stop({ flush: false });
        sendResponse({ ok: true });
        break;
      case MSG.LOAD_MODEL:
        await ensureWorker(msg.settings, { force: msg.force });
        sendResponse({ ok: true, device: state.loadedDevice });
        break;
      case MSG.UNLOAD_MODEL:
        state.worker?.postMessage({ type: 'dispose' });
        state.workerReady = false;
        state.loadedModel = null;
        sendResponse({ ok: true });
        break;
      case MSG.GET_STATE:
        sendResponse({
          ok: true,
          state: state.engine,
          model: state.loadedModel,
          device: state.loadedDevice
        });
        break;
      default:
        sendResponse({ ok: false, error: 'unknown message' });
    }
  })().catch((err) => {
    fail(err);
    sendResponse({ ok: false, error: err?.message || String(err) });
  });

  return true; // async response
});

function fail(err) {
  const message = err?.message || String(err);
  console.error('[LocalDictate/offscreen]', err);
  setEngineState(STATE.ERROR, { message });
  toBackground(MSG.ERROR, { message });
}

/* ------------------------------- worker ---------------------------------- */

async function ensureWorker(settingsOverride, { force = false } = {}) {
  const settings = settingsOverride || (await fetchSettings());
  state.settings = settings;
  const model = MODELS[settings.model] || MODELS.base;

  const needsReload =
    force ||
    !state.worker ||
    !state.workerReady ||
    state.loadedModel !== model.id ||
    (settings.device !== 'auto' && settings.device !== state.loadedDevice);

  if (!needsReload) return;
  if (state.loading) return;

  state.loading = true;
  setEngineState(STATE.LOADING, { model: model.key });

  if (state.worker) {
    state.worker.terminate();
    state.worker = null;
    state.workerReady = false;
  }

  state.worker = new Worker(chrome.runtime.getURL('src/worker/whisper-worker.js'), {
    type: 'module'
  });
  state.worker.onmessage = onWorkerMessage;
  state.worker.onerror = (e) => {
    state.loading = false;
    fail(new Error(e.message || 'Inference worker crashed.'));
  };

  await new Promise((resolve, reject) => {
    const timeout = setTimeout(
      () => reject(new Error('Model load timed out. Check your connection and try again.')),
      15 * 60 * 1000
    );
    state.resolveReady = () => {
      clearTimeout(timeout);
      resolve();
    };
    state.rejectReady = (err) => {
      clearTimeout(timeout);
      reject(err);
    };
    state.worker.postMessage({
      type: 'init',
      modelId: model.id,
      modelKey: model.key,
      device: settings.device,
      wasmBase: chrome.runtime.getURL('lib/ort/')
    });
  }).finally(() => {
    state.loading = false;
  });
}

function onWorkerMessage(event) {
  const msg = event.data;

  switch (msg.type) {
    case 'progress':
      // `status` is one of: initiate | download | progress | done
      toBackground(MSG.MODEL_PROGRESS, {
        file: msg.file,
        status: msg.status,
        loaded: msg.loaded,
        total: msg.total,
        progress: msg.progress
      });
      break;

    case 'ready':
      state.workerReady = true;
      state.loadedModel = msg.modelId;
      state.loadedDevice = msg.device;
      toBackground(MSG.MODEL_READY, { modelId: msg.modelId, device: msg.device });
      setEngineState(state.stream ? STATE.LISTENING : STATE.READY, { device: msg.device });
      state.resolveReady?.();
      break;

    case 'partial':
      if (msg.text) toBackground(MSG.PARTIAL, { text: msg.text });
      break;

    case 'result':
      handleFinal(msg);
      break;

    case 'notice':
      toBackground(MSG.ERROR, { message: msg.message, level: 'notice', code: msg.code });
      break;

    case 'error':
      state.rejectReady?.(new Error(msg.message));
      fail(new Error(msg.message));
      break;

    case 'skipped':
    case 'dropped':
      break;
  }
}

function handleFinal(msg) {
  if (state.engine === STATE.TRANSCRIBING) {
    setEngineState(state.stream ? STATE.LISTENING : STATE.READY);
  }
  if (msg.text) {
    toBackground(MSG.FINAL, {
      text: msg.text,
      ms: msg.ms,
      seconds: msg.seconds,
      device: msg.device
    });
  }
  // Drain anything that arrived while we were busy.
  if (state.pendingFinal) {
    const queued = state.pendingFinal;
    state.pendingFinal = null;
    sendToWorker(queued, false);
  }
}

function sendToWorker(audio, partial) {
  if (!state.workerReady) return;
  if (!partial) setEngineState(STATE.TRANSCRIBING);
  state.worker.postMessage(
    {
      type: 'transcribe',
      id: ++state.seq,
      audio,
      language: state.settings?.language,
      partial
    },
    [audio.buffer]
  );
}

/* ------------------------------ capture ---------------------------------- */

async function start(settingsOverride) {
  const settings = settingsOverride || (await fetchSettings());
  state.settings = settings;

  await ensureWorker(settings);

  if (state.stream) return; // already capturing

  let stream;
  try {
    stream = await navigator.mediaDevices.getUserMedia({
      audio: {
        channelCount: 1,
        echoCancellation: true,
        noiseSuppression: true,
        autoGainControl: true
      }
    });
  } catch (err) {
    const denied = err?.name === 'NotAllowedError' || err?.name === 'SecurityError';
    toBackground(MSG.ERROR, {
      message: denied
        ? 'Microphone access is blocked. Open LocalDictate settings to grant it.'
        : `Could not open the microphone: ${err?.message || err}`,
      code: denied ? 'mic-denied' : 'mic-error'
    });
    setEngineState(STATE.READY);
    return;
  }

  state.stream = stream;
  state.audioCtx = new AudioContext({ sampleRate: SAMPLE_RATE });
  await state.audioCtx.audioWorklet.addModule(chrome.runtime.getURL('src/offscreen/pcm-processor.js'));

  state.source = state.audioCtx.createMediaStreamSource(stream);
  state.node = new AudioWorkletNode(state.audioCtx, 'pcm-processor');
  state.node.port.onmessage = (e) => onFrame(e.data);
  state.source.connect(state.node);
  // Terminate the graph without producing output.
  const sink = state.audioCtx.createGain();
  sink.gain.value = 0;
  state.node.connect(sink).connect(state.audioCtx.destination);

  state.vad = new VAD({
    sampleRate: SAMPLE_RATE,
    threshold: settings.vadThreshold,
    silenceMs: settings.silenceMs
  });
  resetUtterance();
  setEngineState(STATE.LISTENING, { device: state.loadedDevice });
}

function resetUtterance() {
  state.utterance = [];
  state.utteranceSamples = 0;
  state.lastPartialAt = 0;
}

function onFrame(frame) {
  if (!state.vad) return;
  const settings = state.settings;
  const { level, started, ended, voiced } = state.vad.process(frame);

  const now = performance.now();
  if (now - state.levelSentAt > 80) {
    state.levelSentAt = now;
    toBackground(MSG.LEVEL, { level, voiced });
  }

  const gateOpen = settings.vadEnabled ? state.vad.speaking || voiced : true;

  if (started) setEngineState(STATE.SPEAKING);

  if (gateOpen) {
    state.utterance.push(frame);
    state.utteranceSamples += frame.length;

    const elapsedMs = (state.utteranceSamples / SAMPLE_RATE) * 1000;
    if (elapsedMs >= settings.maxUtteranceMs) {
      finalizeUtterance();
      return;
    }
    if (now - state.lastPartialAt > settings.partialIntervalMs && elapsedMs > 900) {
      state.lastPartialAt = now;
      sendToWorker(flatten(state.utterance), true);
    }
  }

  if (ended && settings.vadEnabled) finalizeUtterance();
}

function flatten(chunks) {
  const total = chunks.reduce((n, c) => n + c.length, 0);
  const out = new Float32Array(total);
  let offset = 0;
  for (const c of chunks) {
    out.set(c, offset);
    offset += c.length;
  }
  return out;
}

function finalizeUtterance() {
  const samples = state.utteranceSamples;
  const chunks = state.utterance;
  resetUtterance();
  state.vad?.reset();

  if (samples < SAMPLE_RATE * 0.35) return; // shorter than 350 ms: almost certainly a door

  const audio = flatten(chunks);
  if (state.engine === STATE.TRANSCRIBING) {
    state.pendingFinal = audio; // one slot; the newest utterance wins
  } else {
    sendToWorker(audio, false);
  }
}

async function stop({ flush }) {
  if (flush && state.utteranceSamples > 0) finalizeUtterance();
  else resetUtterance();

  if (!flush) state.worker?.postMessage({ type: 'cancel' });

  try {
    state.node?.disconnect();
    state.source?.disconnect();
    if (state.node) state.node.port.onmessage = null;
    state.stream?.getTracks().forEach((t) => t.stop());
    await state.audioCtx?.close();
  } catch {
    /* teardown is best effort */
  }

  state.node = null;
  state.source = null;
  state.stream = null;
  state.audioCtx = null;
  state.vad = null;

  setEngineState(state.workerReady ? STATE.READY : STATE.IDLE);
}

toBackground(MSG.STATE, { state: STATE.IDLE, offscreenReady: true });
