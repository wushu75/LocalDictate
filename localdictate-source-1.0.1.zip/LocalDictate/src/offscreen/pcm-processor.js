/**
 * Collects 128-sample render quanta into 1024-sample frames (64 ms at 16 kHz)
 * and hands them to the main thread. Keeping the worklet this dumb is the
 * point: nothing here can block the audio render deadline.
 */
class PCMProcessor extends AudioWorkletProcessor {
  constructor() {
    super();
    this.frameSize = 1024;
    this.buffer = new Float32Array(this.frameSize);
    this.offset = 0;
  }

  process(inputs) {
    const channel = inputs[0]?.[0];
    if (!channel) return true;

    for (let i = 0; i < channel.length; i++) {
      this.buffer[this.offset++] = channel[i];
      if (this.offset === this.frameSize) {
        const frame = this.buffer.slice(0);
        this.port.postMessage(frame, [frame.buffer]);
        this.offset = 0;
      }
    }
    return true;
  }
}

registerProcessor('pcm-processor', PCMProcessor);
