/**
 * LocalDictate background service worker.
 *
 * Coordinates: hotkeys → offscreen engine → focused tab. It holds no audio and
 * makes no network requests of its own.
 */

import { MSG, STATE, OFFSCREEN_PATH, MIC_PERMISSION_PATH } from '../common/constants.js';
import { getSettings, addHistoryEntry } from '../common/storage.js';
import { postProcess, isNoiseOnly } from '../common/postprocess.js';

const session = {
  state: STATE.IDLE,
  active: false,
  targetTabId: null,
  targetFrameId: 0,
  device: null,
  model: null,
  lastError: null,
  progress: null,
  partial: ''
};

/* --------------------------- offscreen plumbing -------------------------- */

let creating = null;

async function hasOffscreen() {
  if (chrome.runtime.getContexts) {
    const contexts = await chrome.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'] });
    return contexts.length > 0;
  }
  return false;
}

async function ensureOffscreen() {
  if (await hasOffscreen()) return;
  if (creating) return creating;
  creating = chrome.offscreen
    .createDocument({
      url: OFFSCREEN_PATH,
      reasons: ['USER_MEDIA', 'WORKERS'],
      justification:
        'Captures microphone audio and runs on-device speech recognition; neither is possible in a service worker.'
    })
    .catch((err) => {
      if (!/single offscreen/i.test(err?.message || '')) throw err;
    })
    .finally(() => {
      creating = null;
    });
  return creating;
}

async function toOffscreen(type, payload = {}) {
  await ensureOffscreen();
  try {
    return await chrome.runtime.sendMessage({ to: 'offscreen', type, ...payload });
  } catch (err) {
    console.warn('[LocalDictate] offscreen message failed', type, err);
    return { ok: false, error: err?.message };
  }
}

/* ------------------------------ UI signals -------------------------------- */

function paintAction() {
  const listening = session.state === STATE.LISTENING || session.state === STATE.SPEAKING;
  const working = session.state === STATE.TRANSCRIBING || session.state === STATE.LOADING;

  chrome.action.setBadgeText({ text: listening ? 'REC' : working ? '···' : '' });
  chrome.action.setBadgeBackgroundColor({ color: listening ? '#F2A03D' : '#8B80F9' });
  chrome.action.setTitle({
    title: listening
      ? 'LocalDictate — listening (press the hotkey to stop)'
      : 'LocalDictate — start dictating'
  });
}

function broadcast(type, payload = {}) {
  // Popup and options page; failures just mean nothing is open.
  chrome.runtime.sendMessage({ to: 'popup', type, ...payload }).catch(() => {});
}

function toTab(type, payload = {}) {
  if (session.targetTabId == null) return;
  chrome.tabs
    .sendMessage(session.targetTabId, { to: 'content', type, ...payload })
    .catch(() => {});
}

/* ------------------------------- lifecycle -------------------------------- */

async function resolveTargetTab() {
  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  if (!tab || !tab.id) return null;
  if (/^(chrome|edge|about|devtools|chrome-extension):/.test(tab.url || '')) {
    session.targetTabId = null;
    return tab;
  }
  session.targetTabId = tab.id;
  return tab;
}

export async function startDictation() {
  const settings = await getSettings();
  await resolveTargetTab();
  session.active = true;
  session.partial = '';
  toTab(MSG.STATE, { state: STATE.LOADING, hud: settings.showHud });
  const res = await toOffscreen(MSG.START, { settings });
  if (res?.ok === false) {
    session.active = false;
    paintAction();
  }
}

export async function stopDictation({ cancel = false } = {}) {
  session.active = false;
  await toOffscreen(cancel ? MSG.CANCEL : MSG.STOP, {});
  toTab(MSG.STATE, { state: STATE.IDLE });
  paintAction();
}

async function toggleDictation() {
  if (session.active) await stopDictation();
  else await startDictation();
}

/* ------------------------------- commands --------------------------------- */

chrome.commands.onCommand.addListener(async (command) => {
  if (command === 'toggle-dictation') await toggleDictation();
  if (command === 'cancel-dictation') await stopDictation({ cancel: true });
});

/* ------------------------------- messages --------------------------------- */

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.to === 'background') {
    handleBackgroundMessage(msg, sender)
      .then((result) => sendResponse(result ?? { ok: true }))
      .catch((err) => sendResponse({ ok: false, error: err?.message || String(err) }));
    return true;
  }
  return false;
});

async function handleBackgroundMessage(msg, sender) {
  switch (msg.type) {
    /* ---- from the popup / options / content ---- */
    case MSG.TOGGLE:
      await toggleDictation();
      return { ok: true, active: session.active };

    case MSG.START:
      if (msg.tabId) session.targetTabId = msg.tabId;
      else if (sender.tab?.id) session.targetTabId = sender.tab.id;
      await startDictation();
      return { ok: true };

    case MSG.STOP:
      await stopDictation();
      return { ok: true };

    case MSG.CANCEL:
      await stopDictation({ cancel: true });
      return { ok: true };

    case MSG.LOAD_MODEL: {
      const settings = await getSettings();
      session.progress = null;
      return toOffscreen(MSG.LOAD_MODEL, { settings, force: msg.force });
    }

    case MSG.UNLOAD_MODEL:
      return toOffscreen(MSG.UNLOAD_MODEL, {});

    case MSG.GET_STATE:
      return {
        ok: true,
        ...session,
        micGranted: await micGranted()
      };

    case MSG.GET_SETTINGS:
      return { ok: true, settings: await getSettings() };

    case MSG.CAPS:
      return { ok: true, ...(await capabilities()) };

    /* ---- from the offscreen engine ---- */
    case MSG.STATE:
      session.state = msg.state;
      if (msg.device) session.device = msg.device;
      paintAction();
      broadcast(MSG.STATE, { state: msg.state, device: session.device });
      toTab(MSG.STATE, { state: msg.state });
      return { ok: true };

    case MSG.MODEL_PROGRESS:
      session.progress = msg;
      broadcast(MSG.MODEL_PROGRESS, msg);
      return { ok: true };

    case MSG.MODEL_READY:
      session.model = msg.modelId;
      session.device = msg.device;
      session.progress = null;
      broadcast(MSG.MODEL_READY, msg);
      return { ok: true };

    case MSG.LEVEL:
      broadcast(MSG.LEVEL, msg);
      toTab(MSG.LEVEL, msg);
      return { ok: true };

    case MSG.PARTIAL: {
      const settings = await getSettings();
      const text = postProcess(msg.text, settings);
      session.partial = text;
      broadcast(MSG.PARTIAL, { text });
      toTab(MSG.PARTIAL, { text });
      return { ok: true };
    }

    case MSG.FINAL:
      await deliverFinal(msg);
      return { ok: true };

    case MSG.ERROR:
      session.lastError = msg.message;
      broadcast(MSG.ERROR, msg);
      toTab(MSG.ERROR, msg);
      if (msg.code === 'mic-denied') openMicPermission();
      return { ok: true };

    default:
      return { ok: false, error: `Unknown message: ${msg.type}` };
  }
}

async function deliverFinal(msg) {
  const settings = await getSettings();
  const text = postProcess(msg.text, settings);
  session.partial = '';

  if (!text || isNoiseOnly(text)) {
    broadcast(MSG.PARTIAL, { text: '' });
    toTab(MSG.PARTIAL, { text: '' });
    return;
  }

  broadcast(MSG.FINAL, { text, ms: msg.ms, seconds: msg.seconds, device: msg.device });
  await addHistoryEntry({ text, model: session.model, ms: msg.ms });

  if (session.targetTabId != null) {
    chrome.tabs
      .sendMessage(session.targetTabId, {
        to: 'content',
        type: MSG.INSERT,
        text,
        autoSpace: settings.autoSpace,
        insertMode: settings.insertMode
      })
      .catch(() => {
        // The tab is gone or is a restricted page: keep the text reachable.
        broadcast(MSG.ERROR, {
          message: 'No page to type into. The text is saved in your history.',
          level: 'notice'
        });
      });
  }
}

/* ----------------------------- capabilities ------------------------------- */

async function capabilities() {
  // The service worker has no navigator.gpu, so ask the engine.
  await ensureOffscreen();
  const info = await toOffscreen(MSG.GET_STATE, {});
  return {
    device: info?.device || session.device,
    model: info?.model || session.model,
    state: info?.state || session.state
  };
}

async function micGranted() {
  try {
    const status = await navigator.permissions.query({ name: 'microphone' });
    return status.state === 'granted';
  } catch {
    return null; // unknown; the UI shows a neutral prompt
  }
}

function openMicPermission() {
  chrome.tabs.create({ url: chrome.runtime.getURL(MIC_PERMISSION_PATH) });
}

/* ------------------------------ housekeeping ------------------------------ */

chrome.runtime.onInstalled.addListener(async ({ reason }) => {
  paintAction();
  if (reason === 'install') {
    chrome.tabs.create({ url: chrome.runtime.getURL(MIC_PERMISSION_PATH + '?welcome=1') });
  }
});

chrome.runtime.onStartup.addListener(paintAction);

chrome.tabs.onRemoved.addListener((tabId) => {
  if (tabId === session.targetTabId) {
    session.targetTabId = null;
    if (session.active) stopDictation();
  }
});

// A hard stop if the machine sleeps or the user walks away mid-utterance.
chrome.idle?.onStateChanged?.addListener?.((newState) => {
  if (newState !== 'active' && session.active) stopDictation();
});

paintAction();
