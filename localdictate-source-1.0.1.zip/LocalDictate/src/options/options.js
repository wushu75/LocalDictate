import { MSG, MODELS, LANGUAGES, REPO_URL, STORE_URL } from '../common/constants.js';
import {
  getSettings,
  setSettings,
  resetSettings,
  getHistory,
  clearHistory
} from '../common/storage.js';
import { cacheInfo, clearCache, formatBytes } from '../common/idb-cache.js';

const $ = (id) => document.getElementById(id);
let settings = null;

init().catch((err) => toast(err.message || String(err)));

async function init() {
  settings = await getSettings();
  applyTheme(settings.theme);
  $('version').textContent = 'v' + chrome.runtime.getManifest().version;
  $('repoBtn').href = REPO_URL;

  buildTabs();
  buildLanguages();
  buildModelCards();
  bindFields();
  buildRules();
  await refreshShortcuts();
  await refreshCache();
  await refreshHistory();
  await probeGPU();

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.to !== 'popup') return;
    if (msg.type === MSG.MODEL_PROGRESS) onProgress(msg);
    if (msg.type === MSG.MODEL_READY) {
      hideProgress();
      setDevice(msg.device);
      toast('Model ready. You can go offline now.');
    }
    if (msg.type === MSG.ERROR) toast(msg.message);
  });
}

/* --------------------------------- tabs ---------------------------------- */

function buildTabs() {
  const tabs = [...document.querySelectorAll('.tab')];
  tabs.forEach((tab) =>
    tab.addEventListener('click', () => {
      tabs.forEach((t) => t.classList.toggle('active', t === tab));
      document.querySelectorAll('.panel-group').forEach((p) => {
        p.hidden = p.dataset.panel !== tab.dataset.panel;
      });
    })
  );
}

/* -------------------------------- fields --------------------------------- */

const CHECKBOXES = [
  'vadEnabled',
  'autoSpace',
  'showHud',
  'removeFillers',
  'autoCapitalize',
  'smartPunctuation',
  'trailingPunctuation',
  'keepHistory'
];
const SELECTS = ['device', 'language', 'mode', 'insertMode'];
const RANGES = ['vadThreshold', 'silenceMs', 'partialIntervalMs'];

function bindFields() {
  for (const key of CHECKBOXES) {
    const node = $(key);
    node.checked = !!settings[key];
    node.addEventListener('change', () => save({ [key]: node.checked }));
  }

  for (const key of SELECTS) {
    const node = $(key);
    node.value = settings[key];
    node.addEventListener('change', () => {
      save({ [key]: node.value });
      if (key === 'mode') $('pushKeyField').hidden = node.value !== 'push';
    });
  }
  $('pushKeyField').hidden = settings.mode !== 'push';

  for (const key of RANGES) {
    const node = $(key);
    node.value = settings[key];
    node.addEventListener('input', () => {
      paintRanges();
      save({ [key]: Number(node.value) });
    });
  }
  paintRanges();

  $('historyLimit').value = settings.historyLimit;
  $('historyLimit').addEventListener('change', (e) =>
    save({ historyLimit: Math.max(10, Number(e.target.value) || 100) })
  );

  $('pushKey').textContent = prettyKey(settings.pushKey);
  $('pushKey').addEventListener('click', captureKey);

  $('themeBtn').textContent = `Theme: ${settings.theme}`;
  $('themeBtn').addEventListener('click', () => {
    const order = ['system', 'dark', 'light'];
    const next = order[(order.indexOf(settings.theme) + 1) % order.length];
    save({ theme: next });
    applyTheme(next);
    $('themeBtn').textContent = `Theme: ${next}`;
  });

  $('shortcutsBtn').addEventListener('click', () =>
    chrome.tabs.create({ url: 'chrome://extensions/shortcuts' })
  );

  $('loadBtn').addEventListener('click', async () => {
    showProgress(0, 'Preparing…');
    await chrome.runtime.sendMessage({ to: 'background', type: MSG.LOAD_MODEL, force: true });
  });
  $('unloadBtn').addEventListener('click', async () => {
    await chrome.runtime.sendMessage({ to: 'background', type: MSG.UNLOAD_MODEL });
    toast('Model unloaded. Memory released.');
  });

  $('clearCacheBtn').addEventListener('click', async () => {
    await chrome.runtime.sendMessage({ to: 'background', type: MSG.UNLOAD_MODEL });
    await clearCache();
    await refreshCache();
    toast('Downloaded models deleted.');
  });

  $('clearHistoryBtn').addEventListener('click', async () => {
    await clearHistory();
    await refreshHistory();
    toast('History cleared.');
  });

  $('exportHistoryBtn').addEventListener('click', exportHistory);
  $('shareBtn').addEventListener('click', share);
  $('addRule').addEventListener('click', () => {
    settings.customReplacements = [...(settings.customReplacements || []), { from: '', to: '' }];
    buildRules();
  });
  $('resetBtn').addEventListener('click', async () => {
    settings = await resetSettings();
    location.reload();
  });
}

function paintRanges() {
  $('vadValue').textContent = `Gate at ${Number($('vadThreshold').value).toFixed(3)} RMS`;
  $('silenceValue').textContent = `${$('silenceMs').value} ms`;
  $('partialValue').textContent = `${($('partialIntervalMs').value / 1000).toFixed(1)} s`;
}

async function save(patch) {
  settings = await setSettings(patch);
}

/* ------------------------------ model cards ------------------------------ */

function buildModelCards() {
  const wrap = $('modelCards');
  wrap.textContent = '';
  for (const model of Object.values(MODELS)) {
    const card = document.createElement('button');
    card.className = 'model-card';
    card.type = 'button';
    card.setAttribute('role', 'radio');
    card.setAttribute('aria-checked', String(settings.model === model.key));
    card.innerHTML = `
      <h3>${model.label}</h3>
      <span class="size">${model.downloadSize} · ${model.params}</span>
      <p>${model.blurb}</p>
      <div class="bars" title="Relative accuracy">
        ${[1, 2, 3].map((n) => `<i class="${n <= model.accuracy ? 'on' : ''}"></i>`).join('')}
      </div>`;
    card.addEventListener('click', async () => {
      await save({ model: model.key });
      buildModelCards();
    });
    wrap.appendChild(card);
  }
}

function buildLanguages() {
  const sel = $('language');
  for (const [code, name] of LANGUAGES) {
    const opt = document.createElement('option');
    opt.value = code;
    opt.textContent = name;
    sel.appendChild(opt);
  }
}

/* ------------------------------ replacements ----------------------------- */

function buildRules() {
  const wrap = $('rules');
  wrap.textContent = '';
  const rules = settings.customReplacements || [];

  rules.forEach((rule, index) => {
    const row = document.createElement('div');
    row.className = 'rule';

    const from = document.createElement('input');
    from.type = 'text';
    from.value = rule.from || '';
    from.placeholder = 'heard as';

    const arrow = document.createElement('span');
    arrow.className = 'arrow';
    arrow.textContent = '→';

    const to = document.createElement('input');
    to.type = 'text';
    to.value = rule.to || '';
    to.placeholder = 'written as';

    const remove = document.createElement('button');
    remove.className = 'btn tiny ghost';
    remove.textContent = 'Remove';

    const commit = () => {
      rules[index] = { from: from.value.trim(), to: to.value };
      save({ customReplacements: rules.filter((r) => r.from) });
    };
    from.addEventListener('change', commit);
    to.addEventListener('change', commit);
    remove.addEventListener('click', () => {
      rules.splice(index, 1);
      save({ customReplacements: rules });
      buildRules();
    });

    row.append(from, arrow, to, remove);
    wrap.appendChild(row);
  });

  if (!rules.length) {
    const empty = document.createElement('p');
    empty.className = 'help';
    empty.textContent = 'No replacements yet. Add one for a name or an acronym you use often.';
    wrap.appendChild(empty);
  }
}

/* -------------------------------- capture -------------------------------- */

function captureKey() {
  const btn = $('pushKey');
  btn.classList.add('capturing');
  btn.textContent = 'Press a key…';
  const onKey = (e) => {
    e.preventDefault();
    window.removeEventListener('keydown', onKey, true);
    btn.classList.remove('capturing');
    btn.textContent = prettyKey(e.code);
    save({ pushKey: e.code });
  };
  window.addEventListener('keydown', onKey, true);
}

function prettyKey(code = '') {
  return code
    .replace('ControlRight', 'Right Ctrl')
    .replace('ControlLeft', 'Left Ctrl')
    .replace('AltRight', 'Right Alt')
    .replace('AltLeft', 'Left Alt')
    .replace('ShiftRight', 'Right Shift')
    .replace('ShiftLeft', 'Left Shift')
    .replace('Key', '')
    .replace('Digit', '');
}

/* ------------------------------- readouts -------------------------------- */

async function refreshShortcuts() {
  const commands = await chrome.commands.getAll();
  $('shortcutList').textContent = commands
    .filter((c) => c.description)
    .map((c) => `${c.description}: ${c.shortcut || 'unassigned'}`)
    .join(' · ');
}

async function refreshCache() {
  const info = await cacheInfo();
  $('cacheInfo').textContent = info.files
    ? `${formatBytes(info.bytes)} across ${info.files} files — ${info.models.join(', ')}`
    : 'No models downloaded yet. The first load fetches one from huggingface.co.';
}

async function refreshHistory() {
  const history = await getHistory();
  const wrap = $('historyList');
  wrap.textContent = '';
  if (!history.length) {
    const p = document.createElement('p');
    p.className = 'help';
    p.textContent = 'Nothing recorded yet.';
    wrap.appendChild(p);
    return;
  }
  for (const entry of history.slice(0, 50)) {
    const item = document.createElement('div');
    item.className = 'history-item';
    const t = document.createElement('time');
    t.textContent = new Date(entry.at).toLocaleString();
    item.appendChild(t);
    item.append(entry.text);
    wrap.appendChild(item);
  }
}

async function exportHistory() {
  const history = await getHistory();
  const body = history
    .slice()
    .reverse()
    .map((h) => `[${new Date(h.at).toLocaleString()}] ${h.text}`)
    .join('\n');
  const blob = new Blob([body || 'No transcripts yet.'], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `localdictate-history-${new Date().toISOString().slice(0, 10)}.txt`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}

async function probeGPU() {
  const help = $('gpuHelp');
  if (!('gpu' in navigator)) {
    help.textContent =
      'WebGPU is not exposed in this browser, so LocalDictate will use WebAssembly on the CPU. Tiny and Base still run comfortably.';
    return;
  }
  try {
    const adapter = await navigator.gpu.requestAdapter();
    help.textContent = adapter
      ? 'WebGPU is available. Whisper will run on your GPU, which is typically 3–8× faster than CPU.'
      : 'WebGPU is present but no adapter was returned. LocalDictate will use WebAssembly instead.';
    setDevice(adapter ? 'webgpu' : 'wasm');
  } catch {
    help.textContent = 'WebGPU could not be queried. LocalDictate will use WebAssembly.';
  }
}

function setDevice(device) {
  const chip = $('deviceChip');
  chip.textContent = device === 'webgpu' ? 'WebGPU' : 'WASM';
  chip.dataset.device = device;
}

/* -------------------------------- progress -------------------------------- */

const files = new Map();

function onProgress(msg) {
  if (msg.file) files.set(msg.file, { loaded: msg.loaded || 0, total: msg.total || 0 });
  let loaded = 0;
  let total = 0;
  for (const f of files.values()) {
    loaded += f.loaded;
    total += f.total;
  }
  const pct = total ? Math.min(100, (loaded / total) * 100) : 0;
  showProgress(pct, total ? `${formatBytes(loaded)} of ${formatBytes(total)}` : 'Preparing…');
}

function showProgress(pct, text) {
  $('progressWrap').hidden = false;
  $('progressFill').style.width = `${pct}%`;
  $('progressText').textContent = text;
}

function hideProgress() {
  $('progressWrap').hidden = true;
  files.clear();
}

/* ---------------------------------- misc ---------------------------------- */

function applyTheme(theme) {
  const resolved =
    theme === 'system'
      ? window.matchMedia('(prefers-color-scheme: light)').matches
        ? 'light'
        : 'dark'
      : theme;
  document.documentElement.dataset.theme = resolved;
}

async function share() {
  const message =
    `I've been using LocalDictate — free voice typing for Chrome that runs Whisper entirely on your own machine. ` +
    `No account, no upload, works offline once the model is downloaded.\n\n` +
    `Chrome Web Store: ${STORE_URL}\n` +
    `Source (MIT): ${REPO_URL}`;
  await navigator.clipboard.writeText(message);
  toast('Share message copied to your clipboard.');
}

let toastTimer = null;
function toast(text) {
  const node = $('toast');
  node.textContent = text;
  node.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (node.hidden = true), 3600);
}
