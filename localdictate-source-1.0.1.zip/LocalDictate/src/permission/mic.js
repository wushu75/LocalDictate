import { getSettings } from '../common/storage.js';

const lamp = document.getElementById('lamp');
const statusText = document.getElementById('statusText');
const grantBtn = document.getElementById('grantBtn');

(async () => {
  const settings = await getSettings();
  const resolved =
    settings.theme === 'system'
      ? window.matchMedia('(prefers-color-scheme: light)').matches
        ? 'light'
        : 'dark'
      : settings.theme;
  document.documentElement.dataset.theme = resolved;

  const commands = await chrome.commands.getAll();
  const toggle = commands.find((c) => c.name === 'toggle-dictation');
  if (toggle?.shortcut) document.getElementById('hotkey').textContent = toggle.shortcut;

  if (new URLSearchParams(location.search).has('welcome')) {
    document.getElementById('title').textContent = 'Welcome to LocalDictate';
  }

  await check();
})();

async function check() {
  try {
    const status = await navigator.permissions.query({ name: 'microphone' });
    paint(status.state);
    status.onchange = () => paint(status.state);
  } catch {
    paint('prompt');
  }
}

function paint(state) {
  if (state === 'granted') {
    lamp.dataset.state = 'ready';
    statusText.textContent = 'Microphone access granted. You can close this tab.';
    grantBtn.textContent = 'Granted';
    grantBtn.disabled = true;
  } else if (state === 'denied') {
    lamp.dataset.state = 'error';
    statusText.textContent =
      'Chrome is blocking the microphone for this extension. Use the padlock icon in the address bar to allow it.';
    grantBtn.textContent = 'Try again';
    grantBtn.disabled = false;
  } else {
    lamp.dataset.state = 'idle';
    statusText.textContent = 'Microphone access not granted yet';
  }
}

grantBtn.addEventListener('click', async () => {
  grantBtn.disabled = true;
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    stream.getTracks().forEach((t) => t.stop());
    paint('granted');
  } catch (err) {
    paint(err?.name === 'NotAllowedError' ? 'denied' : 'prompt');
    grantBtn.disabled = false;
  }
});

document.getElementById('settingsBtn').addEventListener('click', () => chrome.runtime.openOptionsPage());
