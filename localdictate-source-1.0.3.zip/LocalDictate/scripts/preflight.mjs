#!/usr/bin/env node
/**
 * Model-download preflight.
 *
 * The Web Store review rejected 1.0.2 because "Load Model" did not work: the
 * manifest's connect-src defaulted to 'self', silently blocking every weight
 * download, and the host allowlist predated Hugging Face's move to Xet-backed
 * storage. This script checks the configuration that governs that download so
 * the same class of failure is caught here, not by a reviewer.
 *
 * It verifies statically (no network needed):
 *   - connect-src exists and covers the Hugging Face hosts
 *   - host_permissions covers the same
 *   - the model repo IDs are well-formed
 *
 * With --live it additionally fetches one small config file per model to prove
 * the repos resolve. --live needs outbound access to huggingface.co.
 *
 * Run: npm run preflight          (static)
 *      npm run preflight -- --live (also hits the network)
 */

import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const live = process.argv.includes('--live');

let failures = 0;
const ok = (m) => console.log(`  \u2713 ${m}`);
const bad = (m) => {
  failures++;
  console.log(`  \u2717 ${m}`);
};

// The hosts a Transformers.js weight download can currently be redirected to.
// Per HF guidance, allowlisting the hf.co / huggingface.co suffixes is the
// durable choice because specific endpoints change.
const DOWNLOAD_HOSTS = [
  'huggingface.co',
  'cdn-lfs.hf.co',
  'cdn-lfs-us-1.hf.co',
  'cas-bridge.xethub.hf.co',
  'transfer.xethub.hf.co'
];

function matchesPattern(host, pattern) {
  // pattern like https://*.hf.co/*  or  https://huggingface.co/*
  const m = /^https:\/\/([^/]+)\/\*?$/.exec(pattern);
  if (!m) return false;
  const hostPart = m[1];
  if (hostPart.startsWith('*.')) {
    const suffix = hostPart.slice(1); // ".hf.co"
    return host.endsWith(suffix);
  }
  return host === hostPart;
}

function cspAllows(connectSrc, host) {
  return connectSrc.some((src) => {
    if (src === "'self'" || src === '*') return src === '*';
    const m = /^https:\/\/([^/]+)$/.exec(src);
    if (!m) return false;
    const hostPart = m[1];
    if (hostPart.startsWith('*.')) return host.endsWith(hostPart.slice(1));
    return host === hostPart;
  });
}

async function main() {
  console.log(`\nModel-download preflight${live ? ' (live)' : ''}\n${'\u2500'.repeat(40)}`);
  const manifest = JSON.parse(await readFile(path.join(root, 'manifest.json'), 'utf8'));

  // 1. connect-src
  console.log('\nCSP connect-src');
  const csp = manifest.content_security_policy?.extension_pages || '';
  const connectMatch = /connect-src ([^;]+)/.exec(csp);
  if (!connectMatch) {
    bad("no connect-src directive — defaults to 'self', which blocks ALL model downloads");
  } else {
    const sources = connectMatch[1].trim().split(/\s+/);
    for (const host of DOWNLOAD_HOSTS) {
      cspAllows(sources, host)
        ? ok(`connect-src permits ${host}`)
        : bad(`connect-src does NOT permit ${host} — its downloads will be blocked`);
    }
  }

  // 2. host_permissions
  console.log('\nhost_permissions');
  const hosts = manifest.host_permissions || [];
  for (const host of DOWNLOAD_HOSTS) {
    hosts.some((p) => matchesPattern(host, p))
      ? ok(`host_permissions covers ${host}`)
      : bad(`host_permissions does NOT cover ${host}`);
  }

  // 3. model ids
  console.log('\nModel repositories');
  const src = await readFile(path.join(root, 'src/common/constants.js'), 'utf8');
  const ids = [...src.matchAll(/id:\s*'([^']+)'/g)].map((m) => m[1]);
  if (!ids.length) bad('no model ids found in constants.js');
  for (const id of ids) {
    /^[\w.-]+\/[\w.-]+$/.test(id) ? ok(`${id} is a well-formed repo id`) : bad(`${id} looks malformed`);
  }

  // 4. optional live check
  if (live) {
    console.log('\nLive resolve (one config file per model)');
    for (const id of ids) {
      const url = `https://huggingface.co/${id}/resolve/main/config.json`;
      try {
        const res = await fetch(url, { method: 'GET' });
        res.ok
          ? ok(`${id} \u2192 HTTP ${res.status}`)
          : bad(`${id} \u2192 HTTP ${res.status} (repo or file unavailable)`);
      } catch (err) {
        bad(`${id} \u2192 ${err.message} (network blocked here? try from a normal machine)`);
      }
    }
  } else {
    console.log('\n  (run with --live to also fetch one file per model)');
  }

  console.log(`${'\u2500'.repeat(40)}`);
  if (failures) {
    console.log(`\n  ${failures} problem(s). "Load Model" will likely fail for users.\n`);
    process.exit(1);
  }
  console.log('\n  Download configuration looks correct.\n');
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
