# Changelog

All notable changes to LocalDictate are recorded here. The format follows
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and the project uses
[semantic versioning](https://semver.org/).

## [1.0.3] — 2026-07-23

### Fixed
- **"Load Model" did not work** (Chrome Web Store rejection, ref "Red
  Potassium"). Two causes, both in the manifest:
  - The `content_security_policy` had no `connect-src` directive, so it
    defaulted to `'self'` and silently blocked every model-weight download.
    `connect-src` now allows the Hugging Face hosts.
  - `host_permissions` predated Hugging Face's migration to Xet-backed storage
    and pointed at retired `cdn-lfs.huggingface.co` hosts. It now allowlists the
    `hf.co` and `huggingface.co` suffixes, which per Hugging Face's own guidance
    survive endpoint changes and cover the current `*.xethub.hf.co` backend.

### Added
- `npm run preflight` verifies the download configuration — that `connect-src`
  and `host_permissions` both cover every host a weight download can be
  redirected to, and (with `--live`) that each model repo resolves. This is the
  check that would have caught the rejection before submission.
- A failed weight download now surfaces a specific, actionable error in the UI
  instead of appearing to hang, so a genuine network problem is distinguishable
  from a broken build.

## [1.0.2] — 2026-07-23

### Removed
- The `scripting` permission and the optional `notifications` permission. Neither
  had a single call site — content scripts are declared statically in the
  manifest, and nothing in the extension ever raised a system notification.
  Declaring an unused permission is a Web Store rejection risk and cannot be
  honestly justified in the listing.
- A dead `chrome.idle` listener that could never fire, since `idle` was not
  among the declared permissions.

### Changed
- `resolveTargetTab()` no longer reads `tab.url`. That read requires the broad
  `tabs` permission and bought nothing: restricted pages have no content script,
  so delivery already fails gracefully through the existing error path.

### Added
- `npm run validate` now audits permissions in both directions — every declared
  permission must have a call site, and any API that strictly requires a
  permission must have it declared.

## [1.0.1] — 2026-07-23

### Fixed
- The Chrome Web Store rejected the upload: `manifest.description` was 139
  characters against a 132 limit. It now carries the same 126-character line
  used as the store's short description, so the two cannot drift apart.
- The audio engine failed to start with `Cannot read properties of undefined
  (reading 'local')`. `src/common/storage.js` read `chrome.storage.local` at
  module scope, and offscreen documents are granted only `chrome.runtime` — so
  merely importing the module threw before any function could run. Settings are
  now resolved lazily, and the offscreen document requests them from the service
  worker via `get-settings` instead of importing the storage module at all.

### Added
- `npm run validate` now walks the import graph from the offscreen document and
  the inference worker and fails on any `chrome.*` API beyond `chrome.runtime`,
  including ones pulled in transitively. This is the check that would have
  caught the bug above before it ever loaded.
- `npm run validate` also enforces every Web Store manifest string limit
  (`name` 75, `short_name` 12, `description` 132, `version_name` 45) and the
  version-string format, so a rejection now surfaces locally in a second rather
  than after a 5 MB upload.

## [1.0.0] — 2026-07-23

First public release.

### Added
- On-device speech recognition with Whisper Tiny, Base and Small.
- WebGPU inference with an automatic WebAssembly fallback.
- Model download with per-file progress and IndexedDB caching.
- Toggle hotkey (`Ctrl+Shift+D`) and hold-to-talk on a configurable key.
- Automatic insertion into inputs, textareas and contenteditable regions,
  with a clipboard fallback for canvas editors such as Google Docs.
- Energy-based voice activity detection with an adaptive noise floor.
- Post-processing: filler removal, sentence capitalisation, punctuation
  spacing, spoken punctuation commands and user-defined replacements.
- In-page listening HUD with a live level meter and partial transcript.
- Local transcript history with export, plus dark and light themes.
